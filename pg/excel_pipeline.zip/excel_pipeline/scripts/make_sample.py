"""Create sample files for testing: a valid workbook and a corrupt one.

Usage: python scripts/make_sample.py ./data
"""
import sys
from pathlib import Path

from openpyxl import Workbook

out = Path(sys.argv[1] if len(sys.argv) > 1 else "data")
out.mkdir(parents=True, exist_ok=True)

wb = Workbook()
ws = wb.active
ws.title = "Executives"
ws.append(["company", "executive", "fiscal_year", "salary", "bonus"])
for i in range(1, 251):
    ws.append([f"Company {i % 25}", f"Exec {i}", 2025, 400_000 + i * 1000, 50_000])
peers = wb.create_sheet("PeerGroup")
peers.append(["company", "peer"])
for i in range(40):
    peers.append([f"Company {i % 25}", f"Peer {i}"])
wb.save(out / "comp_2025.xlsx")

(out / "corrupt.xlsx").write_bytes(b"this is not really an excel file")
print(f"Wrote {out / 'comp_2025.xlsx'} (290 data rows) and {out / 'corrupt.xlsx'}")
