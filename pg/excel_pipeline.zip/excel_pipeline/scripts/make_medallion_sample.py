"""Sample consultant workbooks for the bronze -> silver -> gold pipeline.

Usage: python scripts/make_medallion_sample.py ./data/inbox
Writes:
  acme_2025.xlsx   20 good rows + 4 bad rows + a 'Notes' sheet (not exec-comp layout)
  globex_2025.xlsx 10 good rows, one of which overlaps acme with a new salary
"""
import sys
from pathlib import Path

from openpyxl import Workbook

HEADERS = ["Company", "Executive", "Fiscal Year", "Salary", "Bonus"]
out = Path(sys.argv[1] if len(sys.argv) > 1 else "data/inbox")
out.mkdir(parents=True, exist_ok=True)

wb = Workbook()
ws = wb.active
ws.title = "Executives"
ws.append(HEADERS)
for i in range(20):
    ws.append([f"Company {i % 5}", f"Exec {i}", 2025, f"{400_000 + i * 10_000:,}", 50_000])
ws.append(["", "Exec X", 2025, 300_000, 0])            # missing company
ws.append(["Company 1", "Exec Y", "FY25", 300_000, 0])  # bad fiscal year
ws.append(["Company 1", "Exec Z", 2025, "n/a", 0])      # salary not a number
ws.append(["Company 2", "Exec W", 2025, -5, 0])         # negative salary
notes = wb.create_sheet("Notes")
notes.append(["Note"])
notes.append(["Prepared by consultant; draft"])
wb.save(out / "acme_2025.xlsx")

wb2 = Workbook()
ws2 = wb2.active
ws2.title = "Executives"
ws2.append(HEADERS)
ws2.append(["Company 0", "Exec 0", 2025, 999_000, 75_000])  # updates acme's Exec 0
for i in range(100, 109):
    ws2.append([f"Company {i % 3}", f"Exec {i}", 2024, 350_000 + i * 1000, 25_000])
wb2.save(out / "globex_2025.xlsx")
print(f"Wrote samples to {out}")
