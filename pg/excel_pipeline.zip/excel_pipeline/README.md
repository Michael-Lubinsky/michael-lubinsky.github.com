# Excel processing pipeline: FastAPI + Redis + Celery + Postgres

```
POST /process {"file_path": "/data/x.xlsx"}
      │
      ▼
 FastAPI ──1. INSERT row (QUEUED)──────────────► Postgres: excel_task_status
      │                                                 ▲
      └─2. enqueue (task_id = row id)──► Redis ──► Celery worker
                                                        │ STARTED  (start_time)
                                                        │ process the workbook
                                                        └ SUCCESS / FAILURE (end_time)
GET /tasks/{task_id}  → reads the row
```

## Run with Docker

```bash
mkdir -p data && python scripts/make_sample.py ./data   # sample files (needs openpyxl)
docker compose up --build
```

```bash
# submit (the path is as the containers see it)
curl -X POST localhost:8000/process -H 'Content-Type: application/json' \
     -d '{"file_path": "/data/comp_2025.xlsx"}'
# → 202 {"task_id": "...", "task_status": "QUEUED", "status_url": "/tasks/..."}

curl localhost:8000/tasks/<task_id>
psql postgresql://pipeline:pipeline@localhost:5432/pipeline \
     -c "SELECT excel_file_name, start_time, end_time, task_status FROM excel_task_status;"
```

Interactive API docs: http://localhost:8000/docs

## Run without Docker (on-prem Linux)

```bash
pip install -r requirements.txt
export DATABASE_URL=postgresql://pipeline:pipeline@localhost:5432/pipeline
export REDIS_URL=redis://localhost:6379/0
export EXCEL_BASE_DIR=/data
uvicorn app.main:app --port 8000                          # terminal 1
celery -A app.celery_app worker -Q excel -l info -c 2     # terminal 2
```

In production, run both commands as systemd services (`Restart=always`); logs go to journald.

## The table

| Column | Meaning |
| --- | --- |
| `task_id` | Primary key, and the Celery task id |
| `excel_file_name` | Fully qualified path |
| `start_time` | When a worker started the job |
| `end_time` | When it finished (SUCCESS or FAILURE) |
| `task_status` | `QUEUED` → `STARTED` → `SUCCESS` / `FAILURE` |
| `rows_processed`, `error_message`, `created_at` | Extras for debugging and auditing |

## Design decisions

- **The row is inserted before enqueueing.** Postgres and Redis can't share a transaction. Writing the row first means a worker never starts on a row that doesn't exist yet. If the enqueue fails, the API marks the row FAILURE and returns 503.
- **One id everywhere.** The API generates a UUID and passes it as Celery's `task_id`, so the table row and the Celery task are the same id.
- **No Celery result backend.** Postgres is the source of truth for status, and `task_ignore_result=True`.
- **At-least-once delivery, with idempotent tasks.** `acks_late` plus `task_reject_on_worker_lost` mean a crashed worker's job is redelivered. `mark_started` refuses to rerun a SUCCESS row, so duplicates are harmless.
- **Retry only transient errors.** Database connection errors retry with backoff (up to 3 times). A corrupt or missing file fails immediately. `on_failure` records FAILURE once, after the final attempt, so no row gets stuck in STARTED.
- **Time limits plus visibility timeout.** The soft limit is 25 min and the hard limit is 30 min. The Redis visibility timeout (2 h) is longer than the hard limit, so Redis never redelivers a job that's still running.
- **`worker_prefetch_multiplier=1`.** Excel jobs are long, so one worker shouldn't reserve jobs another worker could start.
- **Path safety.** Paths must be absolute, must resolve inside `EXCEL_BASE_DIR` (which blocks `../` traversal and symlinks pointing elsewhere), and must be `.xlsx`/`.xlsm` files that exist.
- **The business logic is isolated.** `excel_processor.process_workbook()` doesn't import Celery or the database. Replace it with your real validation and loading.

## Responses

| Case | HTTP |
| --- | --- |
| Accepted | 202 |
| Relative path | 400 |
| Outside `EXCEL_BASE_DIR` | 403 |
| File doesn't exist | 404 |
| Not .xlsx / .xlsm | 415 |
| Redis unreachable | 503 (row recorded as FAILURE) |

## Next steps for production

- Use a connection pool (`psycopg_pool`) instead of a connection per call.
- Add authentication on the API.
- Add an alert on rows stuck in STARTED longer than the time limit, and on FAILURE counts.
- Use `.xls` (old format) support only if needed: add `xlrd`.

## Bronze → silver → gold (`app/medallion.py`, `sql/medallion.sql`)

```
scan_inbox (Celery Beat, every 10 min)
   └─ for each new .xlsx:  load_bronze.s(path) | build_silver.s() | refresh_gold.s()
nightly-gold-refresh (Beat, 02:15)  →  refresh_gold(force=True)
```

| Layer | Table | Contents |
| --- | --- | --- |
| meta | `meta.load_runs` | One row per file: hash, status, row counts, error |
| bronze | `bronze.excel_rows` | Every row as JSONB, keyed by header text; append-only |
| silver | `silver.executive_comp`, `silver.rejects` | Typed, validated, deduplicated rows; bad rows with a reason |
| gold | `gold.comp_benchmarks` | Materialized view: salary percentiles by fiscal year |

Try it:

```bash
python scripts/make_medallion_sample.py ./data/inbox
docker compose up --build          # beat triggers scan_inbox within 10 minutes, or:
docker compose exec worker python -c "from app.medallion import run_pipeline; run_pipeline('/data/inbox/acme_2025.xlsx')"
```

Guarantees:
- **The same file never loads twice:** the SHA-256 is unique in `load_runs` (a renamed copy is caught too).
- **Each layer is all-or-nothing:** bronze and silver each run in one transaction, so a rerun after a failure is safe.
- **Resumable:** if bronze succeeded but silver failed, the next run skips straight to silver.
- **Failures are recorded:** `load_runs.status = FAILED` with the error, and the chain stops (silver and gold don't run).
- **Gold refresh is non-blocking:** `REFRESH ... CONCURRENTLY` lets consultants keep reading.

Known limitation: when two files update the same executive-year concurrently, which file wins depends on timing.
In production, add a precedence rule (e.g. the newest filing or file date wins) to the upsert's WHERE clause.
