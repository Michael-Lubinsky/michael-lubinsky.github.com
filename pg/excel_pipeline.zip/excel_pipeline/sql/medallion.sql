-- Bronze -> silver -> gold layers for consultant Excel files.
-- Safe to run repeatedly (IF NOT EXISTS / OR REPLACE everywhere).

CREATE SCHEMA IF NOT EXISTS meta;
CREATE SCHEMA IF NOT EXISTS bronze;
CREATE SCHEMA IF NOT EXISTS silver;
CREATE SCHEMA IF NOT EXISTS gold;

-- ---------------------------------------------------------------- meta
CREATE TABLE IF NOT EXISTS meta.load_runs (
    load_id        bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    source_file    text        NOT NULL,
    file_sha256    text        NOT NULL,
    status         text        NOT NULL DEFAULT 'STARTED'
                   CHECK (status IN ('STARTED', 'BRONZE_DONE', 'SILVER_DONE', 'FAILED')),
    rows_bronze    int,
    rows_silver    int,
    rows_rejected  int,
    started_at     timestamptz NOT NULL DEFAULT now(),
    finished_at    timestamptz,
    error_message  text,
    CONSTRAINT uq_load_runs_file_sha256 UNIQUE (file_sha256)  -- same file never loads twice
);

CREATE OR REPLACE FUNCTION meta.set_updated_at() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END $$;

-- Text -> numeric, or NULL if it isn't a number ("450,000", "$1,200" are fine).
CREATE OR REPLACE FUNCTION meta.to_numeric_or_null(v text) RETURNS numeric
LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
  RETURN replace(replace(trim(v), ',', ''), '$', '')::numeric;
EXCEPTION WHEN others THEN
  RETURN NULL;
END $$;

-- -------------------------------------------------------------- bronze
-- Raw rows exactly as found, one JSONB object per row keyed by header text.
CREATE TABLE IF NOT EXISTS bronze.excel_rows (
    load_id     bigint NOT NULL REFERENCES meta.load_runs (load_id),
    sheet_name  text   NOT NULL,
    row_num     int    NOT NULL,
    raw         jsonb  NOT NULL,
    ingested_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (load_id, sheet_name, row_num)
);

-- -------------------------------------------------------------- silver
CREATE TABLE IF NOT EXISTS silver.executive_comp (
    id             bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    company_name   text          NOT NULL,
    executive_name text          NOT NULL,
    fiscal_year    int           NOT NULL CHECK (fiscal_year BETWEEN 1990 AND 2100),
    salary         numeric(14,2) CHECK (salary >= 0),
    bonus          numeric(14,2) CHECK (bonus >= 0),
    load_id        bigint        NOT NULL REFERENCES meta.load_runs (load_id),
    created_at     timestamptz   NOT NULL DEFAULT now(),
    updated_at     timestamptz   NOT NULL DEFAULT now(),
    CONSTRAINT uq_exec_comp UNIQUE (company_name, executive_name, fiscal_year)
);
CREATE INDEX IF NOT EXISTS ix_exec_comp_load_id ON silver.executive_comp (load_id);

DROP TRIGGER IF EXISTS trg_exec_comp_updated_at ON silver.executive_comp;
CREATE TRIGGER trg_exec_comp_updated_at
BEFORE UPDATE ON silver.executive_comp
FOR EACH ROW EXECUTE FUNCTION meta.set_updated_at();

CREATE TABLE IF NOT EXISTS silver.rejects (
    load_id     bigint NOT NULL REFERENCES meta.load_runs (load_id),
    sheet_name  text   NOT NULL,
    row_num     int    NOT NULL,
    raw         jsonb  NOT NULL,
    reason      text   NOT NULL,
    rejected_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_rejects_load_id ON silver.rejects (load_id);

-- ---------------------------------------------------------------- gold
CREATE MATERIALIZED VIEW IF NOT EXISTS gold.comp_benchmarks AS
SELECT fiscal_year,
       count(*)                                             AS n_execs,
       percentile_cont(0.25) WITHIN GROUP (ORDER BY salary) AS salary_p25,
       percentile_cont(0.50) WITHIN GROUP (ORDER BY salary) AS salary_p50,
       percentile_cont(0.75) WITHIN GROUP (ORDER BY salary) AS salary_p75,
       round(avg(salary + coalesce(bonus, 0)), 2)           AS avg_cash_comp
FROM silver.executive_comp
GROUP BY fiscal_year;

-- Required for REFRESH MATERIALIZED VIEW CONCURRENTLY
CREATE UNIQUE INDEX IF NOT EXISTS ux_comp_benchmarks ON gold.comp_benchmarks (fiscal_year);
