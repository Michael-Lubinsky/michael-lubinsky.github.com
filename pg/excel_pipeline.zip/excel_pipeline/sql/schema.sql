-- Status table for Excel processing jobs ("table T").
-- One row per submitted job. The four requested columns are
-- excel_file_name, start_time, end_time, task_status; the rest support
-- lookups, debugging and auditing.

CREATE TABLE IF NOT EXISTS excel_task_status (
    task_id          uuid        PRIMARY KEY,               -- same id as the Celery task
    excel_file_name  text        NOT NULL,                  -- fully qualified path
    start_time       timestamptz,                           -- set when a worker picks it up
    end_time         timestamptz,                           -- set on SUCCESS or FAILURE
    task_status      text        NOT NULL DEFAULT 'QUEUED'
                     CHECK (task_status IN ('QUEUED', 'STARTED', 'SUCCESS', 'FAILURE')),
    rows_processed   integer,
    error_message    text,
    created_at       timestamptz NOT NULL DEFAULT now()     -- when the API accepted it
);

CREATE INDEX IF NOT EXISTS ix_excel_task_status_file
    ON excel_task_status (excel_file_name, created_at DESC);
