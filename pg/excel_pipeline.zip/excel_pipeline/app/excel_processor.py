"""The actual Excel work. Replace process_workbook() with your business logic
(validate, load into staging tables, etc.). It is kept free of Celery and
database code so it can be unit-tested on its own."""
import logging
from pathlib import Path

from openpyxl import load_workbook

log = logging.getLogger(__name__)


class ExcelProcessingError(Exception):
    """Bad input: retrying will not help, so the task fails immediately."""


def process_workbook(path: Path) -> int:
    """Read every sheet and return the number of non-empty data rows."""
    if not path.is_file():
        raise ExcelProcessingError(f"File not found: {path}")

    try:
        # read_only streams rows, so large files don't load fully into memory.
        wb = load_workbook(path, read_only=True, data_only=True)
    except Exception as exc:  # corrupt file, wrong format, password-protected
        raise ExcelProcessingError(f"Cannot open workbook: {exc}") from exc

    total = 0
    try:
        for ws in wb.worksheets:
            rows = ws.iter_rows(values_only=True)
            next(rows, None)  # skip the header row
            sheet_rows = sum(
                1 for row in rows if any(v not in (None, "") for v in row)
            )
            log.info("sheet=%s rows=%d", ws.title, sheet_rows)
            total += sheet_rows
    finally:
        wb.close()
    return total
