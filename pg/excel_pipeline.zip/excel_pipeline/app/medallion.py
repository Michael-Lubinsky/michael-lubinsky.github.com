"""Bronze -> silver -> gold pipeline as three Celery tasks plus a scanner.

    load_bronze(file_path) -> load_id | None     raw rows into bronze.excel_rows
    build_silver(load_id)  -> load_id | None     typed, validated rows into silver
    refresh_gold(load_id)  -> None               REFRESH the gold materialized view

Run one file:   run_pipeline("/data/inbox/acme_2025.xlsx")
Scan a folder:  scan_inbox  (scheduled by Celery Beat, see celery_app.py)
"""
import hashlib
import json
import logging
from pathlib import Path

import psycopg
from celery import Task, chain
from openpyxl import load_workbook

from app.celery_app import celery_app
from app.config import DATABASE_URL, EXCEL_BASE_DIR

log = logging.getLogger(__name__)

RETRYABLE = (psycopg.OperationalError,)  # DB restarting / connection dropped


def connect(autocommit: bool = False) -> psycopg.Connection:
    return psycopg.connect(DATABASE_URL, autocommit=autocommit)


class PipelineTask(Task):
    """On final failure, mark the run FAILED in meta.load_runs.

    load_bronze is called with a file path (str); build_silver with a
    load_id (int). The first argument tells us which run to mark.
    """

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        key = args[0] if args else None
        msg = f"{self.name}: {type(exc).__name__}: {exc}"[:2000]
        try:
            with connect(autocommit=True) as conn:
                if isinstance(key, int):
                    conn.execute(
                        "UPDATE meta.load_runs SET status='FAILED', error_message=%s, "
                        "finished_at=now() WHERE load_id=%s",
                        (msg, key),
                    )
                elif isinstance(key, str):
                    conn.execute(
                        "UPDATE meta.load_runs SET status='FAILED', error_message=%s, "
                        "finished_at=now() WHERE source_file=%s AND status='STARTED'",
                        (msg, key),
                    )
        except Exception:
            log.exception("Could not record failure for %s", key)


# ------------------------------------------------------------------ bronze
def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def _copy_workbook(conn: psycopg.Connection, load_id: int, path: Path) -> int:
    """Stream every sheet into bronze with COPY. Returns rows loaded."""
    wb = load_workbook(path, read_only=True, data_only=True)
    n = 0
    try:
        with conn.cursor().copy(
            "COPY bronze.excel_rows (load_id, sheet_name, row_num, raw) FROM STDIN"
        ) as copy:
            for ws in wb.worksheets:
                rows = ws.iter_rows(values_only=True)
                header = next(rows, None)
                if not header:
                    continue
                keys = [str(h).strip() if h is not None else f"col_{i}"
                        for i, h in enumerate(header, start=1)]
                for row_num, values in enumerate(rows, start=2):  # Excel row numbers
                    if all(v in (None, "") for v in values):
                        continue
                    raw = json.dumps(dict(zip(keys, values)), default=str)
                    copy.write_row((load_id, ws.title, row_num, raw))
                    n += 1
    finally:
        wb.close()
    return n


@celery_app.task(bind=True, base=PipelineTask, name="medallion.load_bronze",
                 autoretry_for=RETRYABLE, retry_backoff=True, max_retries=3)
def load_bronze(self, file_path: str) -> int | None:
    path = Path(file_path)
    digest = _sha256(path)

    # 1. Register the run in its own committed transaction, so it is visible
    #    even if the load below fails. ON CONFLICT = this file was seen before.
    with connect(autocommit=True) as conn:
        load_id, status = conn.execute(
            "INSERT INTO meta.load_runs (source_file, file_sha256) VALUES (%s, %s) "
            "ON CONFLICT (file_sha256) DO UPDATE SET source_file = meta.load_runs.source_file "
            "RETURNING load_id, status",
            (str(path), digest),
        ).fetchone()

    if status == "SILVER_DONE":
        log.info("Duplicate file %s (load_id %s already loaded); skipping", path, load_id)
        return None
    if status == "BRONZE_DONE":
        log.info("Bronze already done for load_id %s; resuming at silver", load_id)
        return load_id

    # 2. STARTED or FAILED: (re)load bronze in ONE transaction - all rows or none.
    with connect() as conn:
        with conn.transaction():
            # Row lock: two workers loading the same file take turns.
            (status,) = conn.execute(
                "SELECT status FROM meta.load_runs WHERE load_id=%s FOR UPDATE",
                (load_id,),
            ).fetchone()
            if status in ("BRONZE_DONE", "SILVER_DONE"):
                return load_id
            conn.execute("DELETE FROM bronze.excel_rows WHERE load_id=%s", (load_id,))
            n = _copy_workbook(conn, load_id, path)
            conn.execute(
                "UPDATE meta.load_runs SET status='BRONZE_DONE', rows_bronze=%s, "
                "error_message=NULL WHERE load_id=%s",
                (n, load_id),
            )
    log.info("Bronze: load_id=%s rows=%s file=%s", load_id, n, path)
    return load_id


# ------------------------------------------------------------------ silver
# In production the header -> column mapping would come from a per-template
# config table, so a new consultant template needs config, not code.
PARSE_SQL = """
CREATE TEMP TABLE parsed ON COMMIT DROP AS
SELECT b.load_id, b.sheet_name, b.row_num, b.raw,
       nullif(trim(b.raw->>'Company'), '')                 AS company_name,
       nullif(trim(b.raw->>'Executive'), '')               AS executive_name,
       meta.to_numeric_or_null(b.raw->>'Fiscal Year')::int AS fiscal_year,
       meta.to_numeric_or_null(b.raw->>'Salary')           AS salary,
       meta.to_numeric_or_null(b.raw->>'Bonus')            AS bonus
FROM bronze.excel_rows b
WHERE b.load_id = %(load_id)s
  AND b.raw ? 'Executive'          -- only sheets in the executive-comp layout
"""

REJECT_SQL = """
INSERT INTO silver.rejects (load_id, sheet_name, row_num, raw, reason)
SELECT load_id, sheet_name, row_num, raw,
       CASE WHEN company_name   IS NULL THEN 'missing company'
            WHEN executive_name IS NULL THEN 'missing executive'
            WHEN fiscal_year    IS NULL THEN 'bad or missing fiscal year'
            WHEN fiscal_year NOT BETWEEN 1990 AND 2100 THEN 'fiscal year out of range'
            WHEN salary IS NULL AND raw->>'Salary' IS NOT NULL THEN 'salary is not a number'
            WHEN salary < 0              THEN 'negative salary'
            ELSE 'negative bonus' END
FROM parsed
-- coalesce: a NULL check result (e.g. fiscal_year NULL) must count as "not good"
WHERE NOT coalesce((""" + "{good}" + """), false)
"""

GOOD_ROW = """
    company_name IS NOT NULL AND executive_name IS NOT NULL
    AND fiscal_year BETWEEN 1990 AND 2100
    AND NOT (salary IS NULL AND raw->>'Salary' IS NOT NULL)
    AND coalesce(salary, 0) >= 0 AND coalesce(bonus, 0) >= 0
"""

UPSERT_SQL = """
INSERT INTO silver.executive_comp
       (company_name, executive_name, fiscal_year, salary, bonus, load_id)
SELECT DISTINCT ON (company_name, executive_name, fiscal_year)
       company_name, executive_name, fiscal_year, salary, bonus, load_id
FROM parsed
WHERE coalesce((""" + GOOD_ROW + """), false)
ORDER BY company_name, executive_name, fiscal_year, row_num DESC   -- last row in file wins
ON CONFLICT (company_name, executive_name, fiscal_year) DO UPDATE
SET salary  = EXCLUDED.salary,
    bonus   = EXCLUDED.bonus,
    load_id = EXCLUDED.load_id
WHERE (silver.executive_comp.salary, silver.executive_comp.bonus)
      IS DISTINCT FROM (EXCLUDED.salary, EXCLUDED.bonus)
"""


@celery_app.task(bind=True, base=PipelineTask, name="medallion.build_silver",
                 autoretry_for=RETRYABLE, retry_backoff=True, max_retries=3)
def build_silver(self, load_id: int | None) -> int | None:
    if load_id is None:  # load_bronze said "duplicate file": nothing to do
        return None

    with connect() as conn:
        with conn.transaction():  # all-or-nothing, so a rerun is always safe
            (status,) = conn.execute(
                "SELECT status FROM meta.load_runs WHERE load_id=%s FOR UPDATE",
                (load_id,),
            ).fetchone()
            if status not in ("BRONZE_DONE", "SILVER_DONE"):
                raise RuntimeError(f"load_id {load_id} is {status}, expected BRONZE_DONE")

            params = {"load_id": load_id}
            conn.execute("DELETE FROM silver.rejects WHERE load_id=%(load_id)s", params)
            conn.execute(PARSE_SQL, params)
            rejected = conn.execute(REJECT_SQL.format(good=GOOD_ROW)).rowcount
            changed = conn.execute(UPSERT_SQL).rowcount
            conn.execute(
                "UPDATE meta.load_runs SET status='SILVER_DONE', rows_silver=%s, "
                "rows_rejected=%s, finished_at=now() WHERE load_id=%s",
                (changed, rejected, load_id),
            )
    log.info("Silver: load_id=%s changed=%s rejected=%s", load_id, changed, rejected)
    return load_id


# -------------------------------------------------------------------- gold
@celery_app.task(bind=True, name="medallion.refresh_gold",
                 autoretry_for=RETRYABLE, retry_backoff=True, max_retries=3)
def refresh_gold(self, load_id: int | None = None, force: bool = False) -> None:
    """From a chain: receives build_silver's load_id; None means nothing new.
    From Celery Beat: called with force=True (no previous task)."""
    if load_id is None and not force:
        log.info("Gold: nothing new; skipping refresh")
        return
    with connect(autocommit=True) as conn:
        # CONCURRENTLY: consultants can keep reading the old data meanwhile.
        conn.execute("REFRESH MATERIALIZED VIEW CONCURRENTLY gold.comp_benchmarks")
    log.info("Gold refreshed (load_id=%s, force=%s)", load_id, force)


# --------------------------------------------------------------- launching
def pipeline_for(file_path: str):
    """The workflow for one file, as a signature (not yet sent)."""
    return chain(
        load_bronze.s(file_path),  # .s: partial call; returns load_id
        build_silver.s(),          # .s: receives load_id from load_bronze
        refresh_gold.s(),          # .s: receives load_id (or None) from build_silver
    )


def run_pipeline(file_path: str):
    return pipeline_for(file_path).apply_async()


@celery_app.task(name="medallion.scan_inbox")
def scan_inbox() -> int:
    """Data Hub-style discovery: find Excel files under EXCEL_BASE_DIR and
    start a pipeline for each. The file hash makes rescans harmless."""
    with connect(autocommit=True) as conn:
        done = {r[0] for r in conn.execute(
            "SELECT source_file FROM meta.load_runs WHERE status='SILVER_DONE'")}
    started = 0
    for path in sorted(EXCEL_BASE_DIR.rglob("*.xlsx")):
        if path.name.startswith("~$") or str(path) in done:  # Excel lock files / known
            continue
        run_pipeline(str(path))
        started += 1
    log.info("scan_inbox: started %d pipelines", started)
    return started
