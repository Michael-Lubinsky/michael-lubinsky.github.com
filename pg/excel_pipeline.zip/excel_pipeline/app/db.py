"""All reads and writes to the excel_task_status table."""
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

from app.config import DATABASE_URL

SQL_DIR = Path(__file__).resolve().parent.parent / "sql"
SCHEMA_FILES = [SQL_DIR / "schema.sql", SQL_DIR / "medallion.sql"]


def connect() -> psycopg.Connection:
    # Short-lived connections keep the example simple. For high request
    # rates, switch to psycopg_pool.ConnectionPool.
    return psycopg.connect(DATABASE_URL, autocommit=True, row_factory=dict_row)


def init_schema() -> None:
    with connect() as conn:
        for f in SCHEMA_FILES:
            conn.execute(f.read_text())


def create_job(task_id: str, file_name: str) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT INTO excel_task_status (task_id, excel_file_name, task_status) "
            "VALUES (%s, %s, 'QUEUED')",
            (task_id, file_name),
        )


def mark_started(task_id: str) -> bool:
    """Move the job to STARTED. Returns False if it already succeeded.

    Celery delivers at least once (acks_late, retries, redelivery), so the
    task may run more than once. Refusing to restart a SUCCESS row makes
    the task idempotent.
    """
    with connect() as conn:
        cur = conn.execute(
            "UPDATE excel_task_status "
            "SET task_status = 'STARTED', start_time = now(), end_time = NULL, "
            "    error_message = NULL "
            "WHERE task_id = %s AND task_status <> 'SUCCESS'",
            (task_id,),
        )
        return cur.rowcount == 1


def mark_success(task_id: str, rows_processed: int) -> None:
    with connect() as conn:
        conn.execute(
            "UPDATE excel_task_status "
            "SET task_status = 'SUCCESS', end_time = now(), rows_processed = %s "
            "WHERE task_id = %s",
            (rows_processed, task_id),
        )


def mark_failure(task_id: str, error_message: str) -> None:
    with connect() as conn:
        conn.execute(
            "UPDATE excel_task_status "
            "SET task_status = 'FAILURE', end_time = now(), error_message = %s "
            "WHERE task_id = %s",
            (error_message[:2000], task_id),
        )


def get_job(task_id: str) -> dict | None:
    with connect() as conn:
        return conn.execute(
            "SELECT task_id, excel_file_name, start_time, end_time, task_status, "
            "       rows_processed, error_message, created_at "
            "FROM excel_task_status WHERE task_id = %s",
            (task_id,),
        ).fetchone()
