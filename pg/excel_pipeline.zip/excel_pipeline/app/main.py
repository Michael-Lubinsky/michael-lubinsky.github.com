import logging
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, Field

from app import db
from app.config import ALLOWED_SUFFIXES, EXCEL_BASE_DIR
from app.tasks import process_excel

log = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_schema()  # CREATE TABLE IF NOT EXISTS: safe on every start
    yield


app = FastAPI(title="Excel processing pipeline", lifespan=lifespan)


class ProcessRequest(BaseModel):
    file_path: str = Field(
        ..., description="Fully qualified path, e.g. /data/acme_2026.xlsx"
    )


class Accepted(BaseModel):
    task_id: str
    task_status: str
    status_url: str


class JobStatus(BaseModel):
    task_id: uuid.UUID
    excel_file_name: str
    start_time: datetime | None
    end_time: datetime | None
    task_status: str
    rows_processed: int | None
    error_message: str | None
    created_at: datetime


def validate_path(raw: str) -> Path:
    p = Path(raw)
    if not p.is_absolute():
        raise HTTPException(400, "file_path must be a fully qualified (absolute) path")
    resolved = p.resolve()  # collapses '..' and symlinks
    if not resolved.is_relative_to(EXCEL_BASE_DIR):
        raise HTTPException(403, f"file_path must be inside {EXCEL_BASE_DIR}")
    if resolved.suffix.lower() not in ALLOWED_SUFFIXES:
        raise HTTPException(
            415, f"Unsupported file type; allowed: {sorted(ALLOWED_SUFFIXES)}"
        )
    if not resolved.is_file():
        raise HTTPException(404, f"File not found: {resolved}")
    return resolved


@app.post("/process", status_code=status.HTTP_202_ACCEPTED, response_model=Accepted)
def submit(req: ProcessRequest) -> Accepted:
    path = validate_path(req.file_path)
    task_id = str(uuid.uuid4())

    # 1. Record the job first, so a worker can never start on a row that
    #    doesn't exist yet (DB write and Redis enqueue are not one transaction).
    db.create_job(task_id, str(path))

    # 2. Enqueue with the SAME id, so the Celery task id = the table's task_id.
    try:
        process_excel.apply_async(args=[str(path)], task_id=task_id)
    except Exception as exc:  # e.g. Redis unreachable
        log.exception("Enqueue failed for %s", task_id)
        db.mark_failure(task_id, f"Enqueue failed: {exc}")
        raise HTTPException(503, "Task queue unavailable; try again later")

    return Accepted(task_id=task_id, task_status="QUEUED",
                    status_url=f"/tasks/{task_id}")


@app.get("/tasks/{task_id}", response_model=JobStatus)
def get_status(task_id: uuid.UUID) -> JobStatus:
    row = db.get_job(str(task_id))
    if row is None:
        raise HTTPException(404, "Unknown task_id")
    return JobStatus(**row)


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}
