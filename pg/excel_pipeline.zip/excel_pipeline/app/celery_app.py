from celery import Celery
from celery.schedules import crontab

from app.config import REDIS_URL, REDIS_VISIBILITY_TIMEOUT

celery_app = Celery(
    "excel_pipeline", broker=REDIS_URL, include=["app.tasks", "app.medallion"]
)

# Celery Beat: run ONE beat process  (celery -A app.celery_app beat)
celery_app.conf.beat_schedule = {
    "scan-file-server-every-10-min": {
        "task": "medallion.scan_inbox",
        "schedule": crontab(minute="*/10"),
        "options": {"expires": 9 * 60},          # drop if workers are backed up
    },
    "nightly-gold-refresh": {
        "task": "medallion.refresh_gold",
        "schedule": crontab(hour=2, minute=15),
        "kwargs": {"force": True},               # no previous task, so force it
    },
}

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    # Status lives in Postgres, so no result backend is needed.
    task_ignore_result=True,
    # Ack after the task finishes, so a crashed worker doesn't lose the job.
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    # Excel jobs are long: don't let one worker hoard queued jobs.
    worker_prefetch_multiplier=1,
    # Must exceed the task's hard time limit (see config.py).
    broker_transport_options={"visibility_timeout": REDIS_VISIBILITY_TIMEOUT},
    task_default_queue="excel",
    timezone="UTC",
    broker_connection_retry_on_startup=True,
)
