import logging
from pathlib import Path

import psycopg
from celery import Task
from celery.exceptions import SoftTimeLimitExceeded

from app import db
from app.celery_app import celery_app
from app.config import TASK_SOFT_TIME_LIMIT, TASK_TIME_LIMIT
from app.excel_processor import process_workbook

log = logging.getLogger(__name__)


class StatusTrackingTask(Task):
    """Records FAILURE in Postgres when the task finally gives up.

    on_failure runs once, after all retries are used up (not on each retry),
    so the row never gets stuck in STARTED.
    """

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        try:
            db.mark_failure(task_id, f"{type(exc).__name__}: {exc}")
        except Exception:  # the DB itself may be the thing that's down
            log.exception("Could not record FAILURE for task %s", task_id)


@celery_app.task(
    bind=True,
    base=StatusTrackingTask,
    name="process_excel",
    # Retry only transient errors. A bad file fails the same way every time.
    autoretry_for=(psycopg.OperationalError,),
    retry_backoff=True,
    retry_jitter=True,
    max_retries=3,
    soft_time_limit=TASK_SOFT_TIME_LIMIT,
    time_limit=TASK_TIME_LIMIT,
)
def process_excel(self, file_path: str) -> None:
    task_id = self.request.id  # equals the row's task_id (set by the API)

    if not db.mark_started(task_id):
        log.info("Task %s already succeeded; skipping duplicate run", task_id)
        return

    log.info("Processing %s (task %s)", file_path, task_id)
    try:
        rows = process_workbook(Path(file_path))
    except SoftTimeLimitExceeded:
        raise RuntimeError(f"Timed out after {TASK_SOFT_TIME_LIMIT}s")

    db.mark_success(task_id, rows)
    log.info("Done %s: %d rows", file_path, rows)
