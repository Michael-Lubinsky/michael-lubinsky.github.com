"""Settings read from environment variables (12-factor style)."""
import os
from pathlib import Path

DATABASE_URL = os.getenv(
    "DATABASE_URL", "postgresql://pipeline:pipeline@localhost:5432/pipeline"
)
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")

# The API only accepts files under this directory. The API and the workers
# must both see it at the same path (shared disk / NFS / Docker volume).
EXCEL_BASE_DIR = Path(os.getenv("EXCEL_BASE_DIR", "/data")).resolve()

ALLOWED_SUFFIXES = {".xlsx", ".xlsm"}

# Celery time limits (seconds). The Redis visibility timeout must be longer
# than the hard limit, or Redis re-delivers a task that is still running.
TASK_SOFT_TIME_LIMIT = int(os.getenv("TASK_SOFT_TIME_LIMIT", "1500"))
TASK_TIME_LIMIT = int(os.getenv("TASK_TIME_LIMIT", "1800"))
REDIS_VISIBILITY_TIMEOUT = int(os.getenv("REDIS_VISIBILITY_TIMEOUT", "7200"))
