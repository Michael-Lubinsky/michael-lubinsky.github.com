# arXiv Lecture Notes Digest — six framework implementations

Same task, six harnesses/frameworks, so the differences show up in
**how work is structured**, not in what the task does.

## v2 — external code review and fixes

A thorough external review of v1 found 12 concrete issues plus one
architectural inconsistency. All 12 were confirmed against the actual
code and fixed; the four marked "High" were the ones that mattered
most and are described in detail below. See `CHANGELOG.md` for the
complete list with before/after and how each was verified.

**The most important bug (found in all six implementations):** the
"dedupe against previous runs" step also *recorded* articles as seen,
and it ran before human approval. Reject a digest, and its articles
still vanished from every future run, despite never actually being
published. Fixed by splitting persisted state into two operations that
never happen in the same call:

```
research agents
      |
Candidate[]
      |
filter_unpublished()   <-- READ-ONLY, safe to call while drafting
      |
DigestDraft
      |
  HUMAN APPROVAL
   /          \
reject       approve
  |             |
 stop      write digest.md
              |
        mark_published()   <-- the ONLY function that writes state,
                                called only after a real, approved
                                publish action
```

`shared/state_store.py` now enforces this shape directly: it exports
`load_published`, `filter_unpublished` (read-only), and
`mark_published` (the only writer) — the old combined
`load_seen`/`save_seen`/`dedupe_against_seen` API was deleted outright
rather than kept alongside, specifically so nothing could silently
import the old mutating call and reintroduce the bug. Every framework
implementation was updated to route through this shape; see
`CHANGELOG.md` for how each one now enforces (or, for pi.dev/omp.sh,
merely instructs) the ordering.

Three other high-severity fixes:
- **CrewAI** used to write `digest.md` unconditionally at the bottom
  of the script regardless of the human's answer. The file write now
  only happens inside a `publish_digest` tool the Editor agent must
  choose to call.
- **OpenAI Agents SDK** used `handoffs=[...]` to fan out to two
  specialists, but a handoff *transfers* control — it doesn't fan out
  and return. Replaced with explicit `asyncio.gather(Runner.run(...),
  Runner.run(...))`, which is genuinely parallel and genuinely returns
  both results to the orchestrator.
- **OpenAI Agents SDK**'s `output_guardrail` tripped a tripwire that
  nothing ever caught, so "retry with a wider window" never actually
  happened. Added `run_specialist_with_retry`, which catches
  `OutputGuardrailTripwireTriggered` and reruns with a doubled window.

Also fixed: persistence keyed by version-stripped canonical arXiv ID
instead of title (a reworded title used to dodge dedup entirely);
atomic temp-file+rename writes; a future-dated `published` timestamp
no longer passes the recency filter; `cat:math.*` replaced with an
explicit list of the 32 real math subject-class codes (the wildcard's
behavior against the live API was never verified from this sandbox);
pi.dev's TypeScript client now does real XML parsing via
`fast-xml-parser` instead of regex/string-splitting, checks HTTP
status, and guards against unparseable dates; and — the one the
review called an "architectural inconsistency" — every
implementation's search now **paginates until it passes the day-window
boundary** instead of only ever inspecting the newest 100 submissions,
because without that, widening `days: 14 → 28 → 56` had almost no
effect on any category with more than 100 submissions in 60 days.

## The task

1. Search arXiv **physics** categories (quant-ph, hep-th, cond-mat) for
   lecture-notes-style papers from the last 2 weeks on quantum
   mechanics, QFT, or solid state physics.
2. Search arXiv **math** categories for lecture-notes-style papers from
   the last 2 weeks (any subject).
3. If either search returns fewer than 3 hits, widen the window
   (double it, cap 60 days) and retry, up to 2 retries.
4. Merge, filter out anything already published in a previous run
   (persisted state, read-only at draft time), and produce one
   Markdown digest.
5. Require a human approval step before "publishing" (writing the
   final `digest.md` and recording its articles as published).

`shared/arxiv_client.py` and `shared/state_store.py` hold the piece
that's meant to be identical everywhere — the arXiv Atom API call
(with pagination), the keyword filters, and the published-state store
— so every Python-based implementation below is orchestration logic
only. **One exception, called out explicitly rather than left
implicit** (this was the review's "architectural inconsistency"
finding): pi.dev and omp.sh cannot import Python, so
`pi_dev/arxiv_tools.ts` is a from-scratch TypeScript reimplementation.
Its keyword lists (`PHYSICS_TOPIC_KEYWORDS`, `LECTURE_KEYWORDS`) and
category lists are kept byte-identical in spirit to the Python side by
hand, with a comment in each file pointing at its counterpart — but
"kept in sync by hand" is a real, standing maintenance burden this
project accepts rather than hides.

## Status of what's included

Every Python-based implementation was verified in this environment to
**import cleanly and construct its full object graph** (agents, tasks,
tools, handoffs/gather, the compiled LangGraph state graph, the Claude
Agent SDK's MCP server/subagents) without errors. Beyond that, this
revision adds **behavioral, offline tests** for the specific bugs the
review found — with real network and LLM calls mocked out, since this
sandbox's network allowlist blocks `export.arxiv.org` and no API keys
are configured here:

- `shared/arxiv_client.py`: pagination genuinely fetches more pages
  when the window widens (verified: `days=14` fetches 1 page,
  `days=150` fetches 2, against a mocked multi-page feed); a
  future-dated entry is rejected; `canonicalize_id` strips version
  suffixes correctly.
- `shared/state_store.py`: `filter_unpublished` never writes (checked
  by asserting the file doesn't exist after calling it); a rejected
  digest's articles reappear identically on the next call; approving
  via `mark_published` persists them; a subsequent run correctly
  excludes them; a version-bumped resubmission (`v1` → `v2`) still
  dedupes via canonical ID.
- **LangGraph**: a full simulated run through the compiled graph —
  reject leaves state empty and the same articles reappear next run;
  approve persists them; a third run correctly excludes them.
- **CrewAI**: the `filter_unpublished_titles` and `publish_digest`
  tool functions tested directly (bypassing the LLM) with the same
  reject/approve/re-run sequence.
- **OpenAI Agents SDK**: the retry wrapper tested by mocking
  `Runner.run` to simulate three tripwire-then-success calls,
  confirming the actual widen sequence `14 → 28 → 56`; the
  `asyncio.gather` fan-out timed to confirm it runs concurrently
  (~0.2s wall time for two 0.2s calls, not ~0.4s); the tool functions'
  real `on_invoke_tool` call path tested for the same reject/approve
  sequence.
- **Claude Agent SDK**: the MCP tool handlers tested directly for the
  same reject/approve sequence; the `PreToolUse` hook function tested
  in isolation to confirm it returns a `deny` decision on rejection,
  `{}` (allow) on approval, and passes through untouched for any
  non-`publish_digest` tool call.
- **pi.dev's TypeScript client**: type-checked with `tsc`; the
  `fast-xml-parser`-based parsing tested against entity-encoded and
  version-suffixed mock XML; HTTP-status-check, NaN-date-guard, and
  pagination logic each tested directly in Node.

What still could not be verified here: an actual end-to-end run
against the live arXiv API, and an actual LLM-driven run of any of the
four Python frameworks (no API keys in this sandbox). Run these from a
normal machine with network access and the relevant API key to see a
full run.

## Side-by-side

| | Orchestration unit | Parallel fan-out | Retry/widen mechanism | Persistence | Human approval | Distinctive primitive |
|---|---|---|---|---|---|---|
| **LangGraph** | Graph nodes + edges | Native (two branches from `__start__`) | Explicit conditional edge, re-enters search node | `MemorySaver` checkpointer; state written **only** in the `publish` node, post-approval | `interrupt()` + `Command(resume=...)` — graph genuinely suspends | Explicit, drawable state graph |
| **CrewAI** | Role-based Agents + Tasks | Sequential by default; editor task's `context=[...]` waits on both research tasks | Agent's own tool-calling loop (instructed to retry, not enforced) | A `publish_digest` **tool** — the only one with side effects — called by the Editor only on approval | `Task(human_input=True)` — blocks on literal input | Role/goal/backstory mental model |
| **OpenAI Agents SDK** | Small Agents + explicit `asyncio.gather(Runner.run(...))` | Genuine (`asyncio.gather`, timed and confirmed concurrent) | `output_guardrail` tripwire **caught** by `run_specialist_with_retry`, which reruns with a doubled window | A `publish_digest` tool; state written only there, on approval | A tool call (`request_human_approval`) the orchestrator must invoke | Guardrail exception as a real retry trigger |
| **Claude Agent SDK** | One primary agent + Task-tool subagents | Two subagents launched via `Task` | Subagent's own instructed loop (like CrewAI) | MCP `publish_digest` tool; state written only if the hook allows the call | **`PreToolUse` hook** denies the `publish_digest` call until approved — enforced by the harness, not the model | "Give one agent a computer"; hooks intercept tool execution |
| **pi.dev** | One session, one model, bigger toolbox | None — sequential, inside one transcript | Written as an instruction in `AGENTS.md`; nothing enforces it | Model reads `published.json` read-only at draft time; writes it only in the final, explicitly-approved step | Plain conversational question; nothing blocks an early write except the instructions | Minimal 4-tool core + a single TS extension |
| **omp.sh** | One orchestrator + native subagent spawn | **Native parallel task spawn** (physics + math subagents at once) | Each subagent's own instructed loop | Same read-then-write-only-on-approval split, enforced by instruction only (`omp.config.toml` says so explicitly) | Same gap as pi.dev — instruction-only, not harness-enforced | Persistent Python/Bun kernel callable from the agent's own tools |

## What this actually teaches

- **Control enforcement vs. model discretion.** LangGraph
  (`interrupt()`), the Claude Agent SDK (`PreToolUse` hook), CrewAI
  (`human_input=True`), and OpenAI's SDK (an explicit tool call the
  orchestrator must invoke) all give the human a real pause point. But
  only LangGraph and the Claude Agent SDK make the *state write itself*
  something the harness can block — CrewAI and OpenAI's version rely on
  the agent choosing not to call the publish tool after a rejection,
  same as pi.dev and omp.sh rely on the model following an instruction.
  That's a real, graded difference in enforcement strength, not just
  two ways of phrasing the same guarantee.
- **A guardrail is a validator, not a controller, until something
  catches it.** The OpenAI Agents SDK fix is the clearest illustration:
  `output_guardrail` on its own only produces a pass/fail signal
  (a raised exception). Turning "fail" into "retry with different
  parameters" required an explicit `try`/`except` wrapper in
  orchestrator code — the guardrail is necessary but not sufficient.
- **Where "state" lives.** LangGraph's checkpointer persists the
  *entire graph state* (not just the published-articles file) keyed by
  a thread ID, so a crashed run could resume mid-graph. Everyone else
  treats persistence as "a function that reads/writes one JSON file" —
  functionally equivalent for this task, but LangGraph's version
  generalizes further.
- **Parallelism is a spectrum, and "looks parallel" isn't the same as
  "is parallel."** LangGraph and omp.sh have real native fan-out.
  OpenAI's SDK needed an explicit `asyncio.gather` — its `handoffs`
  primitive, despite superficially looking like delegation, is actually
  sequential control transfer and does not fan out on its own. CrewAI's
  default `Process.sequential` waits on `context=[...]` rather than
  truly forking. pi.dev has no fan-out primitive at all.
- **Vendor lock-in is inversely related to structure.** The two most
  structured tools (LangGraph, CrewAI) are model-agnostic. The two
  "give the agent a computer" harnesses (Claude Agent SDK, omp.sh) are
  the most capable at real OS-level work (files, shell, a live Python
  kernel) but hand you a single powerful agent plus a way to spawn
  narrow helpers, not a graph or a role hierarchy.

## Layout

```
arxiv_digest_agents/
├── CHANGELOG.md              # full list of the 12 review findings + fixes
├── shared/
│   ├── arxiv_client.py       # arXiv search/filter/pagination, used by every Python impl
│   └── state_store.py        # published-state store: filter_unpublished / mark_published split
├── langgraph/digest_graph.py
├── crewai/digest_crew.py
├── openai_agents_sdk/digest_agents.py
├── claude_agent_sdk/digest_agent.py
├── pi_dev/{AGENTS.md, arxiv_tools.ts, package.json, prompts/digest.md, README.md}
├── omp_sh/{omp.config.toml, SYSTEM.md, prompts/*.md, README.md}
└── requirements.txt
```
