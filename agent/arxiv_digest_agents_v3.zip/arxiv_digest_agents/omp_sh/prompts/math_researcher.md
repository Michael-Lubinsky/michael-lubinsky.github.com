Use your Python kernel to fetch `https://export.arxiv.org/api/query`.

Do NOT use the wildcard `cat:math.*` -- its behavior against the live
API hasn't been verified for this project, and a silent partial match
would make this whole branch look like it's working while quietly
returning too few or wrong results. Instead build an explicit OR of
these math.* subject-class codes:

```
math.AC math.AG math.AP math.AT math.CA math.CO math.CT math.CV
math.DG math.DS math.FA math.GM math.GN math.GR math.GT math.HO
math.IT math.KT math.LO math.MG math.MP math.NA math.NT math.OA
math.OC math.PR math.QA math.RA math.RT math.SG math.SP math.ST
```

i.e. `search_query=cat:math.AC+OR+cat:math.AG+OR+...` for all of them,
sorted by submittedDate descending.

Fetch in pages of 100 (`start=0,100,200,...`); after each page, check
whether the OLDEST entry in that page (last one, since results are
newest-first) is already older than your current day window -- if so,
stop fetching more pages; otherwise fetch the next page, up to 5 pages
total. This matters because a fixed single page of 100 results means
widening the day window later has no effect if math.* has more than
100 submissions in that window.

Parse the Atom feed with a real XML parser (not string splitting/regex).
Keep entries published within the last 14 days (reject a future-dated
`published` value) whose title or summary contains lecture-notes
phrasing ("lecture notes", "lectures on", "course notes", "introductory
lectures"), any math subject.

For each match, compute `canonical_id` by stripping any trailing
version suffix (`v1`, `v2`, ...) from the arXiv id.

If you end up with fewer than 3 matching articles, double the day
window (cap 60) and retry, up to 2 retries total.

Report back as JSON: `{ "articles": [{"title": ..., "arxiv_id": ...,
"canonical_id": ...}], "days_used": <int>, "retries": <int> }`.
