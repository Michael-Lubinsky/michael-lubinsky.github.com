"""
OpenAI Agents SDK implementation of the arXiv lecture-notes digest agent.

What this is meant to demonstrate about the OpenAI Agents SDK specifically:
  - Small, focused Agents combined via explicit Python control flow
    (`asyncio.gather` over `Runner.run(...)` calls) rather than a graph
    or a role-playing crew.
  - An `output_guardrail` that validates a specialist's structured
    output and, when it trips, is CAUGHT by an explicit retry wrapper
    that reruns the agent with a widened window -- guardrails as a
    real control-flow trigger, not just a validation label.
  - `function_tool`-wrapped Python functions as tools (thin wrappers
    around the same shared arxiv_client/state_store used everywhere
    else).
  - A human-approval step modeled as a tool call the Editor agent must
    make; the actual state write only happens inside the publish tool,
    gated on that approval.

Fixed after external review (two separate architectural bugs):

  1. The original orchestrator used `handoffs=[physics_agent, math_agent]`
     and instructed the triage agent to "hand off to both". An Agents
     SDK handoff TRANSFERS control to the target agent -- it does not
     fan out to two agents and return control to the orchestrator. The
     original code could not actually get both specialist results back
     into one place the way the task requires. Fixed by dropping
     handoffs entirely: `main()` now calls
     `asyncio.gather(Runner.run(physics_agent, ...), Runner.run(math_agent, ...))`
     directly, which is genuinely parallel and genuinely returns control
     to the orchestrator with both results in hand.

  2. The `output_guardrail` tripped a `tripwire` but nothing ever caught
     it -- the run just failed. There was no code path that actually
     widened the window and retried. Fixed with `run_specialist_with_retry`,
     which calls `Runner.run`, catches `OutputGuardrailTripwireTriggered`,
     reads `days_used`/`hit_count` off the tripped agent's own tentative
     output (via `exc.guardrail_result.agent_output`), and reruns with a
     doubled window, up to MAX_RETRIES times. This is what makes the
     guardrail an actual retry mechanism instead of just a label.

  Also (matching the CrewAI/Claude SDK fixes): the dedupe step is now
  read-only (`filter_unpublished`), and only `publish_digest` -- called
  once, only on approval -- writes the digest file and marks articles
  published.

Run:
    pip install openai-agents
    export OPENAI_API_KEY=...
    python digest_agents.py
"""
from __future__ import annotations

import asyncio
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from shared.arxiv_client import search_physics_lecture_notes, search_math_lecture_notes, Article
from shared.state_store import load_published, mark_published

from pydantic import BaseModel
from agents import (
    Agent,
    Runner,
    function_tool,
    output_guardrail,
    GuardrailFunctionOutput,
    RunContextWrapper,
)
from agents.exceptions import OutputGuardrailTripwireTriggered

MIN_HITS = 3
MAX_DAYS = 60
MAX_RETRIES = 2
DIGEST_PATH = pathlib.Path(__file__).parent / "digest.md"


class ArticleRef(BaseModel):
    title: str
    arxiv_id: str
    canonical_id: str
    topic_tags: list[str] = []


class SpecialistReport(BaseModel):
    articles: list[ArticleRef]
    days_used: int
    hit_count: int


# ---- tools -------------------------------------------------------------

@function_tool
def search_physics(days: int) -> list[ArticleRef]:
    """Search arXiv physics categories for lecture-notes-style papers on
    quantum mechanics, QFT, or solid state physics published in the last
    `days` days."""
    results = search_physics_lecture_notes(days=days)
    return [
        ArticleRef(title=a.title, arxiv_id=a.arxiv_id, canonical_id=a.canonical_id,
                   topic_tags=a.topic_tags)
        for a in results
    ]


@function_tool
def search_math(days: int) -> list[ArticleRef]:
    """Search arXiv math.* categories for lecture-notes-style papers
    published in the last `days` days."""
    results = search_math_lecture_notes(days=days)
    return [
        ArticleRef(title=a.title, arxiv_id=a.arxiv_id, canonical_id=a.canonical_id, topic_tags=[])
        for a in results
    ]


@function_tool
def filter_unpublished(articles: list[ArticleRef]) -> list[ArticleRef]:
    """READ-ONLY. Given a list of candidate articles, return only the
    ones not already published in a previous run. Does not record
    anything -- safe to call while drafting, before human approval.
    Calling this twice with the same input returns the same result."""
    published = load_published()
    return [a for a in articles if a.canonical_id not in published]


@function_tool
def request_human_approval(digest_markdown: str) -> str:
    """Show the human the digest and block for a yes/no approval.
    Returns 'approved' or 'rejected'."""
    print("\n----- DIGEST PREVIEW -----\n")
    print(digest_markdown)
    answer = input("\nApprove for publishing? [y/N] ").strip().lower()
    return "approved" if answer == "y" else "rejected"


@function_tool
def publish_digest(digest_markdown: str, articles: list[ArticleRef]) -> str:
    """The ONLY tool with side effects. Call this ONLY if the human
    approved via request_human_approval. Writes digest_markdown to
    disk AND records every article in `articles` as published, so
    future runs correctly dedupe them. If the human rejected the
    digest, do NOT call this -- just report that nothing was published."""
    DIGEST_PATH.write_text(digest_markdown)
    mark_published([
        Article(
            arxiv_id=a.arxiv_id,
            canonical_id=a.canonical_id,
            title=a.title,
            published="",
            categories=[],
            summary="",
            topic_tags=a.topic_tags,
        )
        for a in articles
    ])
    return f"Published {len(articles)} articles to {DIGEST_PATH}"


# ---- guardrail: enforce the "min 3 hits, else caller must widen" rule ----

class SearchResultCheck(BaseModel):
    hit_count: int
    days_used: int
    needs_wider_window: bool


@output_guardrail
async def min_hits_guardrail(
    ctx: RunContextWrapper, agent: Agent, output: SpecialistReport
) -> GuardrailFunctionOutput:
    """Trips when the specialist reports fewer than MIN_HITS and hasn't
    already maxed out the window. Tripping RAISES
    OutputGuardrailTripwireTriggered out of Runner.run -- see
    `run_specialist_with_retry` below for the code that actually
    catches this and performs the retry. A guardrail alone only
    validates; something has to catch the exception for "trip" to
    mean "try again", which is exactly the gap the external review
    caught in the previous version of this file."""
    needs_wider = output.hit_count < MIN_HITS and output.days_used < MAX_DAYS
    check = SearchResultCheck(
        hit_count=output.hit_count,
        days_used=output.days_used,
        needs_wider_window=needs_wider,
    )
    return GuardrailFunctionOutput(output_info=check, tripwire_triggered=needs_wider)


# ---- agents --------------------------------------------------------------

physics_agent = Agent(
    name="Physics Researcher",
    instructions=(
        "Use the search_physics tool with the `days` value given in your "
        "input. Report a SpecialistReport with the articles found, the "
        "days window used, and hit_count = len(articles)."
    ),
    tools=[search_physics],
    output_type=SpecialistReport,
    output_guardrails=[min_hits_guardrail],
)

math_agent = Agent(
    name="Math Researcher",
    instructions=(
        "Use the search_math tool with the `days` value given in your "
        "input. Report a SpecialistReport with the articles found, the "
        "days window used, and hit_count = len(articles)."
    ),
    tools=[search_math],
    output_type=SpecialistReport,
    output_guardrails=[min_hits_guardrail],
)

# The Editor agent does the merge/approve/publish steps. It has no
# handoffs -- it receives both specialists' results as plain input text
# (see main()) after the orchestrator itself has gathered them.
editor_agent = Agent(
    name="Digest Editor",
    instructions=(
        "You will receive JSON with 'physics' and 'math' SpecialistReports "
        "already gathered by the orchestrator. "
        "1) Combine both reports' articles into one list. "
        "2) Call filter_unpublished on that combined list (read-only). "
        "3) Compose Markdown with '## Physics' and '## Math' sections "
        "listing only the filtered (unpublished) articles -- physics "
        "entries should note their topic_tags. "
        "4) Call request_human_approval with that markdown. "
        "5) If approved, call publish_digest with the markdown and the "
        "SAME filtered article list, so they get correctly recorded. "
        "If rejected, do NOT call publish_digest -- report that nothing "
        "was published and these articles will be reconsidered next run."
    ),
    tools=[filter_unpublished, request_human_approval, publish_digest],
)


async def run_specialist_with_retry(agent: Agent, days: int = 14) -> SpecialistReport:
    """Explicit retry loop that turns the output_guardrail's tripwire
    into an actual retry: catches OutputGuardrailTripwireTriggered,
    reads the tentative (failing) output off the exception to see what
    window it used, doubles it, and reruns -- up to MAX_RETRIES times.
    This is the piece the previous version of this file was missing."""
    attempt = 0
    current_days = days
    while True:
        try:
            result = await Runner.run(agent, f"days={current_days}")
            return result.final_output_as(SpecialistReport)
        except OutputGuardrailTripwireTriggered as exc:
            tentative: SpecialistReport = exc.guardrail_result.agent_output
            attempt += 1
            if attempt > MAX_RETRIES or tentative.days_used >= MAX_DAYS:
                # Give up gracefully: return what we actually found
                # rather than propagating the exception and losing it.
                return tentative
            current_days = min(tentative.days_used * 2, MAX_DAYS)


async def main():
    # Fixed: genuine parallel fan-out with control returned to the
    # orchestrator, instead of the previous (incorrect) handoff-based
    # "hand off to both" instruction.
    physics_report, math_report = await asyncio.gather(
        run_specialist_with_retry(physics_agent, days=14),
        run_specialist_with_retry(math_agent, days=14),
    )

    editor_input = (
        f"physics report: {physics_report.model_dump_json()}\n"
        f"math report: {math_report.model_dump_json()}"
    )
    result = await Runner.run(editor_agent, editor_input)
    print("\nFINAL OUTPUT:\n", result.final_output)


if __name__ == "__main__":
    asyncio.run(main())
