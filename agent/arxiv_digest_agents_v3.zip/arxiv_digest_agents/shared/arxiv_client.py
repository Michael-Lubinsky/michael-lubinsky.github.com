"""
Shared arXiv client used by every framework implementation in this project.

Keeping this identical across implementations is the point: the interesting
differences between LangGraph / CrewAI / OpenAI Agents SDK / Claude Agent SDK /
pi.dev / omp.sh are in ORCHESTRATION (delegation, branching, state, tool
execution, human approval) -- not in how you happen to call the arXiv API.
Every framework wraps these same two functions as its "tool".

arXiv's public Atom API: https://export.arxiv.org/api/query
No API key required.

--- Revision history -------------------------------------------------------
v2 fixes, from external code review:
  - Pagination: widening the day window now actually fetches more candidate
    entries (fetch pages until an entry falls outside the window, capped),
    instead of re-filtering the same fixed 100 newest submissions. Without
    this, `days: 14 -> 28 -> 56` had almost no effect whenever a category
    has >100 submissions in 60 days, which silently defeats the whole
    widen-and-retry feature.
  - `_within_window` now rejects a future-dated `published` timestamp
    (previously `now - published` could be negative and still satisfy
    `<= timedelta(days=days)`).
  - `cat:math.*` wildcard replaced with an explicit OR of the ~32 real
    math.* arXiv subject-class codes. The API user manual documents
    wildcard support for some fields, but this project has no way to
    verify wildcard category matching against the live API from this
    sandbox (network is blocked here), and a silent partial match would
    make the whole Math branch look structurally fine while quietly
    returning too few or wrong results. An explicit OR list is no
    slower and removes that risk entirely.
  - `Article` now carries a version-stripped `canonical_id`
    (e.g. "2609.00001v2" -> "2609.00001") used as the persistence key,
    because titles change across revisions and are not a stable
    identity ("An Introduction to QFT" vs "An Introduction to QFT:
    Lecture Notes" would both sneak past a title-based dedupe).
"""
from __future__ import annotations

import datetime as dt
import re
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass, asdict
from typing import Sequence

ATOM_NS = "{http://www.w3.org/2005/Atom}"
ARXIV_API = "https://export.arxiv.org/api/query"

# Explicit category codes -- see revision note above on why "cat:math.*"
# is deliberately NOT used.
PHYSICS_CATEGORIES = [
    "quant-ph",   # quantum physics
    "hep-th",     # high energy physics - theory (QFT lives here)
    "cond-mat.str-el",   # strongly correlated electrons (solid state)
    "cond-mat.mes-hall",  # mesoscale / solid state
]

MATH_CATEGORIES = [
    "math.AC", "math.AG", "math.AP", "math.AT", "math.CA", "math.CO",
    "math.CT", "math.CV", "math.DG", "math.DS", "math.FA", "math.GM",
    "math.GN", "math.GR", "math.GT", "math.HO", "math.IT", "math.KT",
    "math.LO", "math.MG", "math.MP", "math.NA", "math.NT", "math.OA",
    "math.OC", "math.PR", "math.QA", "math.RA", "math.RT", "math.SG",
    "math.SP", "math.ST",
]

# Keyword sets per physics sub-topic. A title/abstract must hit "lecture
# notes"-style phrasing AND one of these to count for that sub-topic.
#
# NOTE: pi.dev's arxiv_tools.ts and omp.sh's prompts necessarily
# reimplement this client in TypeScript / plain English instructions,
# since they aren't Python. Keep the keyword lists below byte-identical
# in spirit to pi_dev/arxiv_tools.ts's PHYSICS_TOPIC_KEYWORDS /
# LECTURE_KEYWORDS -- a change on one side and not the other means the
# six implementations are silently comparing different search logic,
# not just different orchestration. This asymmetry is unavoidable (pi.dev
# and omp.sh have no Python runtime to import this module into) and is
# called out explicitly in the top-level README rather than left implicit.
PHYSICS_TOPIC_KEYWORDS = {
    "quantum mechanics": ["quantum mechanic", "quantum theory", "qm "],
    "QFT": ["quantum field theor", "qft", "field theory"],
    "solid state physics": ["solid state", "condensed matter", "many-body", "strongly correlated"],
}
LECTURE_NOTE_KEYWORDS = ["lecture note", "lecture notes", "lectures on", "course note", "introductory lectures"]

MATH_LECTURE_KEYWORDS = LECTURE_NOTE_KEYWORDS  # math side: just "lecture notes", any subject

_VERSION_SUFFIX_RE = re.compile(r"v\d+$")


@dataclass
class Article:
    arxiv_id: str          # as returned by the API, e.g. "2609.00001v2"
    canonical_id: str      # version-stripped, the stable persistence key
    title: str
    published: str  # ISO date
    categories: list[str]
    summary: str
    topic_tags: list[str]  # which sub-topics matched (physics only; empty for math)

    def to_dict(self) -> dict:
        return asdict(self)


def canonicalize_id(arxiv_id: str) -> str:
    """Strip a trailing version suffix ('v1', 'v2', ...) so re-submissions
    of the same paper dedupe against history correctly. Whether a new
    version of an already-published paper should count as "new" is a
    judgment call this project resolves as: no, same canonical_id means
    already reported."""
    return _VERSION_SUFFIX_RE.sub("", arxiv_id)


def _fetch_atom_page(search_query: str, start: int, page_size: int) -> ET.Element:
    params = {
        "search_query": search_query,
        "start": start,
        "max_results": page_size,
        "sortBy": "submittedDate",
        "sortOrder": "descending",
    }
    url = f"{ARXIV_API}?{urllib.parse.urlencode(params)}"
    with urllib.request.urlopen(url, timeout=20) as resp:
        if resp.status != 200:
            raise RuntimeError(f"arXiv request failed: HTTP {resp.status}")
        data = resp.read()
    return ET.fromstring(data)


def _entries_from_feed(feed: ET.Element) -> list[dict]:
    out = []
    for entry in feed.findall(f"{ATOM_NS}entry"):
        arxiv_id = entry.findtext(f"{ATOM_NS}id", default="").rsplit("/", 1)[-1]
        title = " ".join(entry.findtext(f"{ATOM_NS}title", default="").split())
        summary = " ".join(entry.findtext(f"{ATOM_NS}summary", default="").split())
        published = entry.findtext(f"{ATOM_NS}published", default="")
        categories = [
            c.attrib.get("term", "")
            for c in entry.findall(f"{ATOM_NS}category")
        ]
        out.append(
            dict(
                arxiv_id=arxiv_id,
                title=title,
                summary=summary,
                published=published,
                categories=categories,
            )
        )
    return out


def _parse_published(published_iso: str) -> dt.datetime | None:
    try:
        return dt.datetime.fromisoformat(published_iso.replace("Z", "+00:00"))
    except ValueError:
        return None


def _within_window(published_iso: str, days: int, now: dt.datetime | None = None) -> bool:
    """True iff `published` is in [now - days, now]. Explicitly rejects a
    future-dated entry (clock skew, feed bug, bad test fixture): age must
    be non-negative, not just "<= days" -- a published date 3 days in the
    future previously produced `now - published == -3 days`, which is
    `<= timedelta(days=14)` and would have wrongly passed the filter."""
    now = now or dt.datetime.now(dt.timezone.utc)
    published = _parse_published(published_iso)
    if published is None:
        return False
    age = now - published
    return dt.timedelta(0) <= age <= dt.timedelta(days=days)


def _matches_any(text: str, keywords: Sequence[str]) -> bool:
    text = text.lower()
    return any(k.lower() in text for k in keywords)


def _fetch_entries_for_window(
    search_query: str,
    days: int,
    page_size: int = 100,
    max_pages: int = 5,
    now: dt.datetime | None = None,
) -> list[dict]:
    """Page through the (newest-first) feed until an entry falls older
    than the requested window, instead of always inspecting only the
    first `page_size` newest submissions.

    Without this, widening `days` from 14 to 56 has almost no effect
    whenever a category publishes more than `page_size` papers in 60
    days: every request just re-fetches the same newest 100 and
    re-applies a looser date filter to an unchanged candidate set. Here,
    a wider window causes strictly more pages to be fetched, so widening
    can actually surface older qualifying entries.

    `max_pages` is a safety cap (default 5 * 100 = 500 entries) so a
    very active category can't turn a retry into an unbounded crawl.
    """
    now = now or dt.datetime.now(dt.timezone.utc)
    cutoff = now - dt.timedelta(days=days)

    all_entries: list[dict] = []
    for page in range(max_pages):
        feed = _fetch_atom_page(search_query, start=page * page_size, page_size=page_size)
        page_entries = _entries_from_feed(feed)
        if not page_entries:
            break
        all_entries.extend(page_entries)

        oldest_in_page = _parse_published(page_entries[-1]["published"])
        if oldest_in_page is not None and oldest_in_page < cutoff:
            # Sorted descending by submission date: once one entry in
            # this page is older than the window, every subsequent page
            # is older still. Safe to stop.
            break
    return all_entries


def _build_articles(
    entries: list[dict],
    days: int,
    topic_keywords: dict[str, list[str]] | None,
    lecture_keywords: Sequence[str],
    now: dt.datetime | None = None,
) -> list[Article]:
    results: list[Article] = []
    for e in entries:
        if not _within_window(e["published"], days, now=now):
            continue
        blob = f"{e['title']} {e['summary']}"
        if not _matches_any(blob, lecture_keywords):
            continue

        if topic_keywords is not None:
            tags = [
                topic for topic, kws in topic_keywords.items() if _matches_any(blob, kws)
            ]
            if not tags:
                continue
        else:
            tags = []

        results.append(
            Article(
                arxiv_id=e["arxiv_id"],
                canonical_id=canonicalize_id(e["arxiv_id"]),
                title=e["title"],
                published=e["published"],
                categories=e["categories"],
                summary=e["summary"][:280],
                topic_tags=tags,
            )
        )
    return results


def search_physics_lecture_notes(days: int = 14, now: dt.datetime | None = None) -> list[Article]:
    """Search physics categories for lecture-notes-style papers on
    quantum mechanics, QFT, or solid state physics, published in the
    last `days` days."""
    query = " OR ".join(f"cat:{c}" for c in PHYSICS_CATEGORIES)
    entries = _fetch_entries_for_window(query, days=days, now=now)
    return _build_articles(entries, days, PHYSICS_TOPIC_KEYWORDS, LECTURE_NOTE_KEYWORDS, now=now)


def search_math_lecture_notes(days: int = 14, now: dt.datetime | None = None) -> list[Article]:
    """Search math categories for lecture-notes-style papers published
    in the last `days` days (any math subject)."""
    query = " OR ".join(f"cat:{c}" for c in MATH_CATEGORIES)
    entries = _fetch_entries_for_window(query, days=days, now=now)
    return _build_articles(entries, days, None, MATH_LECTURE_KEYWORDS, now=now)


def widen_and_retry(search_fn, days: int, min_hits: int, max_days: int = 60, retries: int = 2):
    """Shared retry/widen helper: several frameworks below re-implement
    this as an explicit graph edge (LangGraph), a crew task-retry
    (CrewAI), or a plain loop (others) -- included here once so the
    logic itself isn't what's being compared."""
    attempt = 0
    current_days = days
    results = search_fn(days=current_days)
    while len(results) < min_hits and attempt < retries and current_days < max_days:
        attempt += 1
        current_days = min(current_days * 2, max_days)
        results = search_fn(days=current_days)
    return results, current_days, attempt


if __name__ == "__main__":
    import json

    phys, days_used, attempts = widen_and_retry(search_physics_lecture_notes, days=14, min_hits=3)
    math, mdays_used, mattempts = widen_and_retry(search_math_lecture_notes, days=14, min_hits=3)
    print(json.dumps({
        "physics": {"days_used": days_used, "retries": attempts, "count": len(phys),
                     "titles": [a.title for a in phys]},
        "math": {"days_used": mdays_used, "retries": mattempts, "count": len(math),
                  "titles": [a.title for a in math]},
    }, indent=2))
