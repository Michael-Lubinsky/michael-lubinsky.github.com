# Changelog: v1 → v2

All 12 numbered findings from an external code review, plus the
architectural-inconsistency note, verified against the actual v1 code
and fixed. "Verified" below means an offline, mocked test was written
and run in this environment to prove the fix — not just that the code
compiles.

## 1. "Seen" state updated before human approval — High

**Was:** `merge_and_dedupe()` (LangGraph) called `save_seen(new_seen)`
before `human_approval()`; CrewAI's `dedupe_tool`, OpenAI's
`dedupe_and_record`, and Claude SDK's `dedupe_tool` did the same.
Rejecting a digest still recorded its articles as seen, so they
silently vanished from every future run despite never being published.

**Fix:** `shared/state_store.py` now exports `filter_unpublished`
(read-only) and `mark_published` (the only writer, called once, only
on the approved path, alongside the actual `digest.md` write). The old
combined API was deleted, not kept alongside, so nothing can
accidentally import the old mutating call. Every framework
implementation was restructured around this split.

**Verified:** `shared/state_store.py` standalone test (reject → file
absent → same articles reappear next call → approve → persisted →
excluded on next call → version-bumped resubmission still dedupes).
Repeated as a full simulated run through the compiled LangGraph graph,
and against the CrewAI/OpenAI SDK/Claude SDK tool functions directly.

## 2. CrewAI writes the digest even after rejection — High

**Was:** `out_path.write_text(str(result))` ran unconditionally at the
bottom of the script regardless of what the human answered.

**Fix:** The file write moved entirely inside a new `publish_digest`
tool, which the Editor agent is instructed to call only on approval.
The bottom of the script now only logs the crew's summary; it does not
write `digest.md` itself.

**Verified:** Called `publish_tool.func(...)` directly and confirmed
`digest.md` and the published-state file are both absent until that
call happens; confirmed `filter_tool.func(...)` never creates either
file.

## 3. OpenAI Agents orchestration via handoffs is conceptually wrong — High

**Was:** The orchestrator used `handoffs=[physics_agent, math_agent]`
and an instruction to "hand off to both". A handoff *transfers*
control to the target agent; it does not fan out to two agents and
return control to the orchestrator with both results.

**Fix:** Removed `handoffs` entirely. `main()` now calls
`asyncio.gather(Runner.run(physics_agent, ...), Runner.run(math_agent,
...))` directly, then a separate `Runner.run(editor_agent, ...)` call
for the merge/approve/publish step — the orchestrator explicitly
regains control with both results.

**Verified:** Timed the `asyncio.gather` call against two mocked
0.2s-sleep coroutines; measured ~0.2s wall time (would be ~0.4s if
sequential), confirming genuine concurrency, and confirmed both
results land back in one place.

## 4. The OpenAI guardrail doesn't actually implement retry — High

**Was:** `output_guardrail` set `tripwire_triggered=True` when results
were thin, but nothing ever caught the resulting
`OutputGuardrailTripwireTriggered` exception — the run just failed.

**Fix:** Added `run_specialist_with_retry`, which calls `Runner.run`,
catches the tripwire exception, reads the tentative (failing) output's
`days_used`/`hit_count` off `exc.guardrail_result.agent_output`,
doubles the window, and reruns — up to `MAX_RETRIES` times.

**Verified:** Mocked `Runner.run` to raise the tripwire twice (at
days=14 and days=28) then succeed at days=56; confirmed the actual
call sequence was `[14, 28, 56]` and the final report was returned
correctly.

## 5. Deduplication by exact title is fragile — Medium

**Was:** Every implementation checked `if title not in seen`. A minor
title reword ("An Introduction to QFT" vs "...: Lecture Notes") would
dodge dedup entirely, despite `Article.arxiv_id` already existing as a
stable identifier.

**Fix:** Added `canonicalize_id()` (strips a trailing `v\d+` version
suffix) and `Article.canonical_id`. `shared/state_store.py` now keys
its store by `canonical_id`, storing `{title, published_at}` per the
review's suggested shape.

**Verified:** A `v1` article marked published; a `v2` resubmission of
the same paper correctly excluded by `filter_unpublished` via matching
`canonical_id`.

## 6. `seen_titles.json` has no atomic/concurrent update protection — Medium

**Was:** `path.write_text(json.dumps(...))` — a crash mid-write could
leave a truncated/corrupt file, and two concurrent runs could silently
drop one's update.

**Fix:** `mark_published` now writes via `tempfile.mkstemp` +
`os.replace` (atomic on POSIX). `load_published` also treats a corrupt
file as empty rather than raising, so a pre-fix corrupt file left over
doesn't crash every subsequent run.

**Verified:** Inspected the implementation directly; the atomic-replace
pattern is standard and was exercised (without fault injection) in
every other test in this changelog that calls `mark_published`.

## 7. `_within_window()` accepts future dates — Low/Medium

**Was:** `(now - published) <= timedelta(days=days)` is `True` for a
future-dated `published` (negative age), since a negative number is
always `<=` a positive one.

**Fix:** `dt.timedelta(0) <= age <= dt.timedelta(days=days)` — age must
be non-negative too. Same fix applied to the TypeScript client
(`ageMs >= 0 && ageMs <= windowMs`).

**Verified:** An entry dated 3 days in the future against a 14-day
window correctly rejected, in both the Python and TypeScript
implementations; a legitimately recent entry still accepted.

## 8. TypeScript doesn't check HTTP status — Medium

**Was:** `const res = await fetch(url); const xml = await res.text();`
— a 429/500/HTML response would be silently parsed into zero papers.

**Fix:** `if (!res.ok) throw new Error(...)` before parsing.

**Verified:** A mocked `{ok: false, status: 429, ...}` response
correctly throws with a descriptive message.

## 9. Regex/XML parsing in the TypeScript implementation is brittle — Medium

**Was:** `xml.split("<entry>")` + `match(/<title>.../)` — fragile
against namespace prefixes, entities, CDATA, or feed formatting
changes; also meant pi.dev was silently running a lower-quality arXiv
client than the Python implementations for a project explicitly about
comparing orchestration, not parsing.

**Fix:** Replaced with `fast-xml-parser` (added as a real dependency in
`pi_dev/package.json`).

**Verified:** Parsed a mock feed containing an HTML entity (`&amp;`)
and a version-suffixed ID; confirmed the entity decoded correctly
(`&amp;` → `&`) and the ID parsed correctly — both would have needed
extra regex-escaping logic under the old approach.

## 10. Invalid dates in TypeScript can accidentally pass filtering — Medium

**Was:** `new Date(publishedIso).getTime()` returns `NaN` for an
invalid string; the surrounding comparison happened to return `false`,
but not explicitly.

**Fix:** `parsePublished()` explicitly checks `Number.isNaN(t)` and
returns `null`; callers check for `null` rather than relying on NaN
comparison semantics.

**Verified:** `parsePublished("not-a-date")` and `parsePublished("")`
both return `null` directly.

## 11. `math.*` deserves verification — Medium

**Was:** `cat:math.*` used as a wildcard in both the Python and
TypeScript clients, untested against the live API (this sandbox has no
network access to `export.arxiv.org`).

**Fix:** Replaced with an explicit `OR` of the 32 real math.*
subject-class codes (`math.AC`, `math.AG`, ..., `math.ST`) in both
`shared/arxiv_client.py`'s `MATH_CATEGORIES` and
`pi_dev/arxiv_tools.ts`'s `MATH_CATEGORIES`, and spelled out
explicitly in `omp_sh/prompts/math_researcher.md` for the
instruction-driven implementations.

**Verified:** Confirmed no implementation still references `math.*`;
confirmed the Python list has exactly 32 entries.

## 12. Search can miss qualifying papers when widening — Medium

**Was:** Every search fetched a fixed `max_results=100`, sorted
newest-first, then filtered locally. Widening `days: 14 → 28 → 56` had
almost no effect whenever a category published more than 100 papers in
60 days, since every request just re-fetched and re-filtered the same
100 newest submissions.

**Fix:** `_fetch_entries_for_window()` (Python) / `fetchEntriesForWindow()`
(TypeScript) now paginate: fetch pages of 100, and after each page,
stop only once the oldest entry in that page falls older than the
requested window (results are sorted newest-first, so this is a safe
early-exit) — capped at 5 pages (500 entries) as a safety limit. A
wider window now genuinely causes more pages to be fetched.

**Verified:** Mocked a two-page feed (page 0: days 1–100 old, page 1:
days 101–200 old). Confirmed `days=14` fetches only page 0 (`[0]`) and
`days=150` fetches both pages (`[0, 100]`) — in both the Python and
TypeScript implementations independently.

## Architectural inconsistency: pi.dev's separate client

**Was:** The README claimed `shared/arxiv_client.py` was "identical
everywhere," but pi.dev necessarily runs its own TypeScript
reimplementation with slightly different keyword lists (missing the
`"qm "` entry in `quantum mechanics`).

**Fix:** Synced the TypeScript keyword lists exactly with the Python
side, and the top-level README now explicitly documents this as an
accepted, hand-maintained exception rather than leaving it implied by
omission.

## One design change applied throughout

Every fix above followed the review's suggested reframing: separate
**discovery state** from **published state**, with exactly one
function (`mark_published`) allowed to write, called only after a real
approval:

```
research agents -> Candidate[]
      -> filter_unpublished()  (read-only)
      -> DigestDraft
      -> HUMAN APPROVAL
         reject -> stop (no state change)
         approve -> write digest.md -> mark_published()
```
