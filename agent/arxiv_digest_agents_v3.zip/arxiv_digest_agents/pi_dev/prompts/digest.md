Build today's arXiv lecture-notes digest exactly as described in AGENTS.md
for this project. Use the `arxiv_search` tool (from the arxiv-digest-tools
extension) for both the physics and math sections, apply the widen-retry
rule, filter (read-only) against `../shared/published.json`, write
`digest.md`, ask me to approve, and only update `published.json` if I
approve.
