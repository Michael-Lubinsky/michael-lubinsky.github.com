"""
CrewAI implementation of the arXiv lecture-notes digest agent.

What this is meant to demonstrate about CrewAI specifically:
  - The ROLE-BASED mental model: three named agents (Physics Researcher,
    Math Researcher, Editor) each with a role/goal/backstory, rather
    than a graph of functions.
  - TASKS assigned to agents, with `context=[...]` wiring one task's
    output into another's input -- CrewAI's version of data flow.
  - A `Crew` that orchestrates execution order (here: two research
    tasks run, an editor task consumes both). CrewAI's retry-on-
    condition is expressed as the Editor agent's own tool-calling
    loop (via a `widen_search` tool) rather than a graph edge --
    this is the "delegate a fuzzy sub-goal to an agent" style, in
    contrast to LangGraph's explicit conditional edges.
  - Human-in-the-loop via Task(human_input=True) -- CrewAI pauses for
    literal console input on that task.

Fixed after external review (two separate bugs):

  1. dedupe_tool used to filter AND persist ("seen") in one call, and
     the Editor task ran it before human_input=True could reject
     anything. Rejecting a digest still silently recorded its titles
     as seen, so they vanished from every future run despite never
     being published. dedupe_tool is now read-only (calls
     filter_unpublished only); a separate publish_digest tool is the
     only place mark_published is called, and the Editor is instructed
     to call it ONLY when the human approved.

  2. The script always executed `out_path.write_text(str(result))`
     at the bottom, unconditionally -- so even a rejected digest got
     written to disk, contradicting the whole point of human_input.
     The file write now happens exclusively inside the publish_digest
     tool, which the Editor only calls on approval; the bottom of the
     script no longer writes digest.md itself, only logs the crew's
     final textual summary for visibility.

Run:
    pip install crewai
    export OPENAI_API_KEY=...   # or configure another LLM via crewai's llm= param
    python digest_crew.py
"""
from __future__ import annotations

import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from shared.arxiv_client import (
    search_physics_lecture_notes,
    search_math_lecture_notes,
    Article,
)
from shared.state_store import load_published, filter_unpublished, mark_published

from crewai import Agent, Task, Crew, Process
from crewai.tools import tool

MIN_HITS = 3
MAX_DAYS = 60
DIGEST_PATH = pathlib.Path(__file__).parent / "digest.md"


# ---- tools each agent can call --------------------------------------------

@tool("search_physics_lecture_notes")
def search_physics_tool(days: int = 14) -> str:
    """Search arXiv physics categories (quant-ph, hep-th, cond-mat) for
    lecture-notes-style papers on quantum mechanics, QFT, or solid state
    physics published in the last `days` days. Returns a JSON list of
    {title, arxiv_id, canonical_id, topic_tags}. If fewer than 3 results
    come back, call this again with a larger `days` value (double it,
    cap at 60)."""
    import json
    results = search_physics_lecture_notes(days=days)
    return json.dumps([
        {"title": a.title, "arxiv_id": a.arxiv_id, "canonical_id": a.canonical_id,
         "topic_tags": a.topic_tags}
        for a in results
    ])


@tool("search_math_lecture_notes")
def search_math_tool(days: int = 14) -> str:
    """Search arXiv math.* categories for lecture-notes-style papers
    published in the last `days` days. Returns a JSON list of
    {title, arxiv_id, canonical_id}. If fewer than 3 results come back,
    call this again with a larger `days` value (double it, cap at 60)."""
    import json
    results = search_math_lecture_notes(days=days)
    return json.dumps([
        {"title": a.title, "arxiv_id": a.arxiv_id, "canonical_id": a.canonical_id}
        for a in results
    ])


@tool("filter_unpublished_titles")
def filter_tool(articles_json: str) -> str:
    """READ-ONLY. Given a JSON list of {title, arxiv_id, canonical_id,
    ...}, return only the ones NOT already published in a previous run.
    Does NOT record anything -- safe to call while drafting, before the
    human has approved. Calling this twice in a row returns the same
    result both times."""
    import json
    articles = json.loads(articles_json)
    published = load_published()
    fresh = [a for a in articles if a.get("canonical_id") not in published]
    return json.dumps(fresh)


@tool("publish_digest")
def publish_tool(markdown: str, published_articles_json: str) -> str:
    """The ONLY tool with side effects. Call this ONLY after the human
    has approved the digest. Writes `markdown` to digest.md AND records
    every article in `published_articles_json` (a JSON list of
    {title, arxiv_id, canonical_id, published}) as published, so future
    runs correctly dedupe them. Do NOT call this if the human rejected
    the digest -- in that case, just report that it was discarded."""
    import json
    DIGEST_PATH.write_text(markdown)
    articles = json.loads(published_articles_json)
    mark_published([
        Article(
            arxiv_id=a.get("arxiv_id", a["canonical_id"]),
            canonical_id=a["canonical_id"],
            title=a["title"],
            published=a.get("published", ""),
            categories=a.get("categories", []),
            summary="",
            topic_tags=a.get("topic_tags", []),
        )
        for a in articles
    ])
    return f"Published {len(articles)} articles to {DIGEST_PATH}"


# ---- agents ----------------------------------------------------------

physics_researcher = Agent(
    role="Physics Lecture Notes Researcher",
    goal=(
        f"Find at least {MIN_HITS} recent arXiv lecture-notes-style papers on "
        "quantum mechanics, QFT, or solid state physics. Start with a 14-day "
        "window; if you get fewer than the minimum, retry with a wider "
        "window (double it, up to 60 days) before giving up."
    ),
    backstory=(
        "A physics postdoc who maintains a reading-group digest of new "
        "pedagogical material and knows exactly which arXiv categories "
        "carry lecture notes."
    ),
    tools=[search_physics_tool],
    verbose=True,
)

math_researcher = Agent(
    role="Math Lecture Notes Researcher",
    goal=(
        f"Find at least {MIN_HITS} recent arXiv lecture-notes-style papers "
        "in any math.* category. Start with a 14-day window; if you get "
        "fewer than the minimum, retry with a wider window (double it, up "
        "to 60 days) before giving up."
    ),
    backstory="A math librarian who tracks new expository/course material on arXiv.",
    tools=[search_math_tool],
    verbose=True,
)

editor = Agent(
    role="Digest Editor",
    goal=(
        "Combine the physics and math findings into one clean Markdown "
        "digest, remove anything already published in a previous run "
        "(read-only check -- never assume something is 'seen' until it's "
        "actually published), get human approval, and ONLY THEN call "
        "publish_digest. If the human rejects it, do not call "
        "publish_digest at all -- just report that nothing was published."
    ),
    backstory=(
        "A careful editor who never writes to the published record "
        "unless a digest has genuinely gone out -- rejected drafts leave "
        "no trace, so nothing is ever lost by saying no."
    ),
    tools=[filter_tool, publish_tool],
    verbose=True,
)


# ---- tasks -------------------------------------------------------------

physics_task = Task(
    description=(
        "Search for recent physics lecture notes as described in your goal. "
        "Report the final list of titles with their arxiv_id, canonical_id, "
        "and topic tags (quantum mechanics / QFT / solid state physics), "
        "and note how many widen-retries you needed."
    ),
    expected_output="A bulleted list of physics lecture-note titles with IDs and tags.",
    agent=physics_researcher,
)

math_task = Task(
    description=(
        "Search for recent math lecture notes as described in your goal. "
        "Report the final list of titles with their arxiv_id and "
        "canonical_id, and note how many widen-retries you needed."
    ),
    expected_output="A bulleted list of math lecture-note titles with IDs.",
    agent=math_researcher,
)

editor_task = Task(
    description=(
        "Take the physics and math results from the two researchers. "
        "1) Call filter_unpublished_titles on the combined list (this is "
        "read-only -- it does not record anything). "
        "2) Produce one Markdown digest with '## Physics' and '## Math' "
        "sections listing only the unpublished titles. "
        "3) Present it to the human for approval (you will be asked). "
        "4) If and ONLY IF approved, call publish_digest with the "
        "markdown and the JSON list of the articles you're publishing. "
        "5) If rejected, do NOT call publish_digest -- report that the "
        "digest was discarded and nothing was recorded, so these same "
        "articles will be reconsidered next run."
    ),
    expected_output=(
        "Either confirmation that publish_digest was called with the "
        "final digest, or a clear statement that the digest was rejected "
        "and nothing was published."
    ),
    agent=editor,
    context=[physics_task, math_task],  # CrewAI wires prior task outputs in here
    human_input=True,  # CrewAI pauses for literal console approval on this task
)


def build_crew() -> Crew:
    return Crew(
        agents=[physics_researcher, math_researcher, editor],
        tasks=[physics_task, math_task, editor_task],
        process=Process.sequential,  # editor_task naturally waits on both via `context`
        verbose=True,
    )


if __name__ == "__main__":
    crew = build_crew()
    result = crew.kickoff()
    # NOTE: we do NOT unconditionally write digest.md here anymore -- that
    # write (and the corresponding mark_published call) only happens
    # inside publish_tool, gated on the editor agent actually deciding
    # the human approved. This is just a log line for the human running
    # the script, not a file write.
    print("\n--- Crew finished ---")
    print(result)
    if DIGEST_PATH.exists():
        print(f"\ndigest.md is present at {DIGEST_PATH} (published this run or a previous one).")
    else:
        print(f"\ndigest.md was not written -- either rejected, or no qualifying articles.")
