"""
"Published" state store, shared by every implementation.

--- Revision history -------------------------------------------------------
v2 redesign, from external code review (this was the most important bug
in the whole project):

  OLD design: a `dedupe` step both filtered AND wrote the updated
  seen-set in one call. Every implementation called it as part of
  building the digest draft -- i.e. BEFORE the human approval step.
  Consequence: reject today's digest, and those same titles vanish
  from tomorrow's run anyway, because they were already recorded as
  "seen" even though they were never actually published.

  NEW design: discovery state and published state are different
  things, and only ONE function is allowed to mutate the store:

      research agents -> Candidate[]
            |
      filter_unpublished()  <-- READ-ONLY, safe to call while drafting
            |
      DigestDraft
            |
        HUMAN APPROVAL
         /          \\
     reject        approve
       |               |
      stop      write digest.md
                       |
                mark_published()  <-- the ONLY function that writes state,
                                       called only after a real approved
                                       publish action

  Every framework implementation in this project was updated to follow
  this shape: whatever it uses for "dedupe" during drafting must be
  read-only, and the write only happens alongside (or after) the actual
  digest.md write, gated on approval.

  Also: keyed by canonical arXiv id (version-stripped) instead of raw
  title, since titles are not a stable identity across revisions or
  minor rewording ("An Introduction to QFT" vs "An Introduction to
  QFT: Lecture Notes" would both dodge a title-based dedupe).

v3 fix, from a second external review: the v2 comment here overstated
what `os.replace` buys you. temp-file + os.replace makes each
*individual write* atomic -- a crash mid-write leaves either the old
file or the new one intact, never a truncated/corrupt one. It does
NOT make the read-modify-write *transaction* safe against two
concurrent callers:

    Process A                 Process B
    read {X}
                               read {X}
    add A
                               add B
    write {X,A}
                               write {X,B}   <-- A's update is lost

`mark_published` now holds an exclusive `fcntl.flock` on a sidecar
`.lock` file for the entire read+merge+write, so a second concurrent
call blocks until the first finishes instead of racing it. This is a
real fix for this project's actual concurrency exposure (a scheduled
run firing while a previous one is still mid-approval-wait), not a
theoretical one. It's a single-machine lock (POSIX `flock`, advisory,
not valid across NFS or multiple hosts) -- fine for a cron-style single
scheduled task; genuinely concurrent multi-process/multi-host
publishing would want a real database (SQLite with `INSERT ... ON
CONFLICT DO NOTHING`, or similar) instead of a JSON file, full stop.
"""
from __future__ import annotations

import contextlib
import fcntl
import json
import os
import pathlib
import tempfile
from typing import Iterable, Iterator

DEFAULT_PATH = pathlib.Path(__file__).parent / "published.json"


def load_published(path: pathlib.Path = DEFAULT_PATH) -> dict[str, dict]:
    """Returns {canonical_id: {title, published, categories}}. Missing
    file -> empty dict (nothing published yet)."""
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except json.JSONDecodeError:
        # A corrupt/truncated file (e.g. from a crash mid-write under the
        # OLD non-atomic save_seen) should not crash every run forever.
        # Treat as empty rather than raising; the next successful
        # mark_published() call will rewrite it cleanly.
        return {}


def filter_unpublished(articles, published: dict[str, dict]):
    """READ-ONLY. Returns the subset of `articles` whose canonical_id is
    not already in `published`. Safe to call at draft time, before
    approval -- it never writes anything."""
    fresh = []
    for a in articles:
        cid = a.canonical_id if hasattr(a, "canonical_id") else a["canonical_id"]
        if cid not in published:
            fresh.append(a)
    return fresh


@contextlib.contextmanager
def _locked(path: pathlib.Path) -> Iterator[None]:
    """Exclusive advisory lock on `path`'s sidecar `.lock` file, held for
    the duration of the `with` block. Blocks (does not fail) if another
    process already holds it -- appropriate here since the whole point
    is to serialize concurrent mark_published() calls, not reject them."""
    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = path.with_suffix(path.suffix + ".lock")
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def mark_published(articles, path: pathlib.Path = DEFAULT_PATH) -> None:
    """The ONLY function that writes state. Call this once, only after
    a digest has actually been approved and written -- never while
    merely drafting or deduping candidates.

    Holds an exclusive lock across the full read-modify-write so two
    concurrent calls (e.g. two overlapping scheduled runs) serialize
    instead of one silently clobbering the other's update -- see the
    v3 revision note above."""
    with _locked(path):
        current = load_published(path)
        for a in articles:
            cid = a.canonical_id if hasattr(a, "canonical_id") else a["canonical_id"]
            title = a.title if hasattr(a, "title") else a["title"]
            published_at = a.published if hasattr(a, "published") else a.get("published", "")
            current[cid] = {"title": title, "published_at": published_at}
        _atomic_write(current, path)


def _atomic_write(data: dict, path: pathlib.Path) -> None:
    """temp-file + os.replace so a crash mid-write leaves either the old
    file or the new one intact, never a truncated/corrupt one. This
    alone does NOT make a read-modify-write transaction concurrency-
    safe -- callers that read-then-write must hold `_locked(path)`
    across the whole transaction, as `mark_published` does above."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(data, f, indent=2, sort_keys=True)
        os.replace(tmp_path, path)
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


# --- Backward-compat note ---------------------------------------------
# The old `load_seen`/`save_seen`/`dedupe_against_seen` (title-keyed,
# read+write conflated) are intentionally removed rather than kept
# alongside the new API -- keeping both would let an implementation
# accidentally import the old mutating call and silently reintroduce
# the exact bug this redesign fixes.
