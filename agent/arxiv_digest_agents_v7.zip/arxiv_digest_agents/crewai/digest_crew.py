"""
CrewAI implementation of the arXiv lecture-notes digest agent.

What this is meant to demonstrate about CrewAI specifically:
  - The ROLE-BASED mental model: three named agents (Physics Researcher,
    Math Researcher, Editor) each with a role/goal/backstory, rather
    than a graph of functions.
  - TASKS assigned to agents, with `context=[...]` wiring one task's
    output into another's input -- CrewAI's version of data flow.
  - A `Crew` that orchestrates execution order (here: two research
    tasks run, an editor task consumes both). CrewAI's retry-on-
    condition is expressed as the Editor agent's own tool-calling
    loop (via a `widen_search` tool) rather than a graph edge --
    this is the "delegate a fuzzy sub-goal to an agent" style, in
    contrast to LangGraph's explicit conditional edges.
  - `Task(output_pydantic=...)` for a structured, host-parseable
    result instead of scraping free text.

Fixed after external review (three separate bugs, across two rounds):

  1. [round 1] dedupe_tool used to filter AND persist ("seen") in one
     call, before approval could reject anything. Fixed: filtering is
     read-only (filter_unpublished), and only one function writes state
     (mark_published), called from host code, only on approval.

  2. [round 1] The script always executed `out_path.write_text(...)`
     unconditionally at the bottom. Fixed: no unconditional write.

  3. [round 2, the bigger one] Even after fix #1/#2, the Editor AGENT
     still held a `publish_digest` TOOL and was merely *instructed*
     "only call this after approval". `Task(human_input=True)` is a
     CrewAI feedback mechanism the agent can incorporate into its next
     thought -- it is NOT a permission gate on a specific tool call.
     So the actual safety property depended on the LLM correctly
     honoring the instructed ordering, which is a materially weaker
     guarantee than e.g. the Claude Agent SDK's PreToolUse hook (which
     can programmatically DENY the tool call itself). Fixed by removing
     the mutating capability from the agent entirely:
       - editor_task now returns a structured DigestDraft
         (`output_pydantic=DigestDraft`) containing the composed
         markdown and the exact article list -- the editor's tools are
         reduced to `filter_unpublished_titles` only (read-only).
       - The actual approval prompt and the actual publish (file write
         + mark_published) both happen in `__main__`, in plain Python,
         entirely outside any agent's control. The LLM never has the
         ability to call "publish" at all, approved or not -- so
         there's nothing for it to get wrong.
     `Task(human_input=True)` was removed since it's now redundant with
     (and could be confused for) the real, host-enforced gate.

Run:
    pip install crewai
    export OPENAI_API_KEY=...   # or configure another LLM via crewai's llm= param
    python digest_crew.py
"""
from __future__ import annotations

import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from shared.arxiv_client import (
    search_physics_lecture_notes,
    search_math_lecture_notes,
    Article,
)
from shared.state_store import load_published, mark_published

from pydantic import BaseModel
from crewai import Agent, Task, Crew, Process
from crewai.tools import tool

MIN_HITS = 3
MAX_DAYS = 60
DIGEST_PATH = pathlib.Path(__file__).parent / "output" / "digest.md"


class ArticleOut(BaseModel):
    title: str
    arxiv_id: str
    canonical_id: str
    topic_tags: list[str] = []


class DigestDraft(BaseModel):
    """Structured output of editor_task -- host code parses this
    directly (`CrewOutput.pydantic`) instead of scraping free text, and
    it is the ONLY channel through which the drafted digest and its
    article list reach the code that will actually publish them."""
    markdown: str
    articles: list[ArticleOut]
    physics_truncated: bool = False
    math_truncated: bool = False


# ---- tools each agent can call --------------------------------------------

@tool("search_physics_lecture_notes")
def search_physics_tool(days: int = 14) -> str:
    """Search arXiv physics categories (quant-ph, hep-th, cond-mat) for
    lecture-notes-style papers on quantum mechanics, QFT, or solid state
    physics published in the last `days` days. Returns a JSON object
    {articles: [{title, arxiv_id, canonical_id, topic_tags}], truncated}.
    `truncated: true` means the scan hit its page cap before reaching
    the window boundary -- treat the result as possibly incomplete, not
    exhaustive. If fewer than 3 results come back, call this again with
    a larger `days` value (double it, cap at 60)."""
    import json
    results, truncated = search_physics_lecture_notes(days=days)
    return json.dumps({
        "articles": [
            {"title": a.title, "arxiv_id": a.arxiv_id, "canonical_id": a.canonical_id,
             "topic_tags": a.topic_tags}
            for a in results
        ],
        "truncated": truncated,
    })


@tool("search_math_lecture_notes")
def search_math_tool(days: int = 14) -> str:
    """Search arXiv math.* categories for lecture-notes-style papers
    published in the last `days` days. Returns a JSON object
    {articles: [{title, arxiv_id, canonical_id}], truncated}.
    `truncated: true` means the scan hit its page cap before reaching
    the window boundary. If fewer than 3 results come back, call this
    again with a larger `days` value (double it, cap at 60)."""
    import json
    results, truncated = search_math_lecture_notes(days=days)
    return json.dumps({
        "articles": [
            {"title": a.title, "arxiv_id": a.arxiv_id, "canonical_id": a.canonical_id}
            for a in results
        ],
        "truncated": truncated,
    })


@tool("filter_unpublished_titles")
def filter_tool(articles_json: str) -> str:
    """READ-ONLY. Given a JSON list of {title, arxiv_id, canonical_id,
    ...}, return only the ones NOT already published in a previous run.
    Does NOT record anything -- safe to call while drafting. Calling
    this twice in a row returns the same result both times. This is the
    ONLY state-touching tool available to any agent in this
    implementation; nothing here can write to the published record."""
    import json
    articles = json.loads(articles_json)
    published = load_published()
    fresh = [a for a in articles if a.get("canonical_id") not in published]
    return json.dumps(fresh)


# ---- agents ----------------------------------------------------------

physics_researcher = Agent(
    role="Physics Lecture Notes Researcher",
    goal=(
        f"Find at least {MIN_HITS} recent arXiv lecture-notes-style papers on "
        "quantum mechanics, QFT, or solid state physics. Start with a 14-day "
        "window; if you get fewer than the minimum, retry with a wider "
        "window (double it, up to 60 days) before giving up. Report whether "
        "the final search was truncated (hit its page cap)."
    ),
    backstory=(
        "A physics postdoc who maintains a reading-group digest of new "
        "pedagogical material and knows exactly which arXiv categories "
        "carry lecture notes."
    ),
    tools=[search_physics_tool],
    verbose=True,
)

math_researcher = Agent(
    role="Math Lecture Notes Researcher",
    goal=(
        f"Find at least {MIN_HITS} recent arXiv lecture-notes-style papers "
        "in any math.* category. Start with a 14-day window; if you get "
        "fewer than the minimum, retry with a wider window (double it, up "
        "to 60 days) before giving up. Report whether the final search was "
        "truncated (hit its page cap)."
    ),
    backstory="A math librarian who tracks new expository/course material on arXiv.",
    tools=[search_math_tool],
    verbose=True,
)

editor = Agent(
    role="Digest Editor",
    goal=(
        "Combine the physics and math findings into one clean Markdown "
        "digest, removing anything already published in a previous run "
        "(read-only check -- never assume something is 'seen' until it's "
        "actually published). You do NOT decide whether to publish and "
        "you have no ability to -- you only draft. A human reviewer "
        "outside this crew makes the actual publish decision."
    ),
    backstory=(
        "A careful editor who prepares the digest for someone else's "
        "sign-off and has no access to the publish button themselves -- "
        "that separation is by design, not an oversight."
    ),
    tools=[filter_tool],  # deliberately no mutating/publish tool
    verbose=True,
)


# ---- tasks -------------------------------------------------------------

physics_task = Task(
    description=(
        "Search for recent physics lecture notes as described in your goal. "
        "Report the final list of titles with their arxiv_id, canonical_id, "
        "and topic tags (quantum mechanics / QFT / solid state physics), "
        "how many widen-retries you needed, and whether the final search "
        "was truncated."
    ),
    expected_output="A bulleted list of physics lecture-note titles with IDs and tags, plus a truncated: true/false note.",
    agent=physics_researcher,
)

math_task = Task(
    description=(
        "Search for recent math lecture notes as described in your goal. "
        "Report the final list of titles with their arxiv_id and "
        "canonical_id, how many widen-retries you needed, and whether the "
        "final search was truncated."
    ),
    expected_output="A bulleted list of math lecture-note titles with IDs, plus a truncated: true/false note.",
    agent=math_researcher,
)

editor_task = Task(
    description=(
        "Take the physics and math results from the two researchers. "
        "1) Call filter_unpublished_titles on the combined list (this is "
        "read-only -- it does not record anything). "
        "2) Produce one Markdown digest with '## Physics' and '## Math' "
        "sections listing only the unpublished titles -- if either "
        "researcher reported truncated=true, add a note under that "
        "section saying the search may be incomplete. Render each "
        "article's arxiv_id as a clickable Markdown link to its arXiv "
        "abstract page, e.g. '- **<title>** _(tags: <tags>)_ — "
        "[<arxiv_id>](https://arxiv.org/abs/<arxiv_id>)', not as bare text. "
        "3) Return a DigestDraft: the composed markdown, the exact list "
        "of articles included (title, arxiv_id, canonical_id, "
        "topic_tags), and the two truncated flags. "
        "You are NOT responsible for approval or publishing -- you only "
        "produce the draft. Someone else decides whether it goes out."
    ),
    expected_output="A DigestDraft with the composed markdown and the article list.",
    agent=editor,
    context=[physics_task, math_task],  # CrewAI wires prior task outputs in here
    output_pydantic=DigestDraft,
)


def build_crew() -> Crew:
    return Crew(
        agents=[physics_researcher, math_researcher, editor],
        tasks=[physics_task, math_task, editor_task],
        process=Process.sequential,  # editor_task naturally waits on both via `context`
        verbose=True,
    )


def publish(draft: DigestDraft) -> None:
    """The ONLY function that writes state, and it is plain host-side
    Python -- no agent, no tool, no LLM judgment call involved. This is
    the actual enforcement boundary: an agent that never had a
    publish-capable tool cannot be talked into calling one early,
    regardless of what its instructions said.

    Note on partial failure: writing digest.md and calling
    mark_published() are two separate operations. If mark_published()
    fails after the file write, we roll the file back out and raise,
    so a failed publish never leaves a digest.md on disk whose articles
    weren't actually recorded -- that would risk duplicating the digest
    on the next run. This is a big-enough guarantee for a single-file
    JSON store; a true atomic transaction would need a real database."""
    DIGEST_PATH.parent.mkdir(parents=True, exist_ok=True)
    DIGEST_PATH.write_text(draft.markdown)
    try:
        mark_published([
            Article(
                arxiv_id=a.arxiv_id,
                canonical_id=a.canonical_id,
                title=a.title,
                published="",
                categories=[],
                summary="",
                topic_tags=a.topic_tags,
            )
            for a in draft.articles
        ])
    except Exception:
        DIGEST_PATH.unlink(missing_ok=True)
        print("PUBLISH FAILED -- could not record published state; "
              "digest.md rolled back so this run is safe to retry.")
        raise
    print(f"APPROVED -- digest written to {DIGEST_PATH}, "
          f"{len(draft.articles)} articles marked published")


if __name__ == "__main__":
    crew = build_crew()
    result = crew.kickoff()

    draft: DigestDraft = result.pydantic
    if draft is None:
        raise RuntimeError(
            "editor_task did not return a structured DigestDraft -- "
            "cannot safely proceed to a host-controlled approval prompt."
        )

    print("\n----- DIGEST PREVIEW -----\n")
    print(draft.markdown)

    # The real, only approval gate in this implementation: a plain
    # Python input() call the agent has no path to bypass, because it
    # never had a tool that could publish in the first place.
    answer = input("\nApprove for publishing? [y/N] ").strip().lower()
    if answer == "y":
        publish(draft)
    else:
        print("NOT APPROVED -- digest discarded, no state changed "
              "(these articles will be reconsidered next run)")
