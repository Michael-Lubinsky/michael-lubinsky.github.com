"""
Claude Agent SDK implementation of the arXiv lecture-notes digest agent.

What this is meant to demonstrate about the Claude Agent SDK specifically:
  - "GIVE ONE CAPABLE AGENT A COMPUTER": a single primary agent with real
    filesystem/tool access does the work end-to-end, rather than several
    small agents passing typed messages. It reads its own state file,
    writes the digest as an actual file, and can shell out if needed --
    no other framework in this comparison writes to disk natively.
  - SUBAGENTS for the two research tracks (Physics / Math), each with a
    narrow tool allowlist -- the SDK's delegation primitive, invoked via
    the Task tool rather than a "handoff" (SDK keeps control with the
    orchestrator) or a "crew" (no persistent role-play, just scoped
    sub-tasks).
  - MCP-STYLE CUSTOM TOOLS (create_sdk_mcp_server) exposing the shared
    arxiv_client functions -- because Anthropic created MCP, this is the
    idiomatic way to hand the agent new capabilities.
  - A HOOK (PreToolUse) that intercepts the "publish" tool call and
    requires human approval before it's allowed to run -- hooks are this
    SDK's lifecycle-interception mechanism, distinct from LangGraph's
    graph-level interrupt() or CrewAI's Task(human_input=True).

Fixed after external review: `dedupe_and_record` used to filter AND
persist ("seen") in one MCP tool call, made available to the
orchestrator BEFORE the PreToolUse hook's approval gate on
publish_digest. Rejecting a digest at the hook still left those
articles recorded as seen -- exactly the same bug pattern found in
every other implementation in this project. Fixed the same way: the
dedupe tool is now read-only (`filter_unpublished`), and only
`publish_digest` writes state, which only happens if the PreToolUse
hook allows the call through.

Fixed after a second external review round:

  - search_physics/search_math now unpack `(articles, truncated)` from
    the shared client and include `truncated` in their JSON reply, so
    the orchestrator/subagents can report when a scan hit its page cap
    before reaching the window boundary rather than treating a capped
    scan as exhaustive.
  - `publish_tool` wrote digest.md and called `mark_published` as two
    separate, unguarded steps. If `mark_published` raised after the
    file write succeeded, digest.md would be left on disk describing
    articles never actually recorded as published. Fixed with
    rollback-on-failure: if `mark_published` raises, the just-written
    digest.md is deleted before the error is surfaced back to the
    model, matching the same pattern used in the LangGraph, CrewAI,
    and OpenAI Agents SDK implementations.

Run:
    pip install claude-agent-sdk
    export ANTHROPIC_API_KEY=...
    python digest_agent.py
"""
from __future__ import annotations

import asyncio
import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from shared.arxiv_client import search_physics_lecture_notes, search_math_lecture_notes, Article
from shared.state_store import load_published, mark_published

from claude_agent_sdk import (
    ClaudeSDKClient,
    ClaudeAgentOptions,
    AgentDefinition,
    create_sdk_mcp_server,
    tool,
    HookMatcher,
)

MIN_HITS = 3
MAX_DAYS = 60
DIGEST_PATH = pathlib.Path(__file__).parent / "output" / "digest.md"


# ---- custom MCP tools, the idiomatic way to extend this SDK -----------

@tool(
    "search_physics",
    "Search arXiv physics categories for lecture-notes-style papers on "
    "quantum mechanics, QFT, or solid state physics within the last N days. "
    "Returns {articles, truncated}; truncated=true means the scan hit its "
    "page-scan cap before reaching the window boundary, so treat the "
    "results as possibly incomplete, not exhaustive.",
    {"days": int},
)
async def search_physics_tool(args):
    results, truncated = search_physics_lecture_notes(days=args["days"])
    payload = {
        "articles": [
            {"title": a.title, "arxiv_id": a.arxiv_id, "canonical_id": a.canonical_id,
             "topic_tags": a.topic_tags}
            for a in results
        ],
        "truncated": truncated,
    }
    return {"content": [{"type": "text", "text": json.dumps(payload)}]}


@tool(
    "search_math",
    "Search arXiv math.* categories for lecture-notes-style papers "
    "within the last N days. Returns {articles, truncated}; truncated=true "
    "means the scan hit its page-scan cap before reaching the window "
    "boundary, so treat the results as possibly incomplete, not exhaustive.",
    {"days": int},
)
async def search_math_tool(args):
    results, truncated = search_math_lecture_notes(days=args["days"])
    payload = {
        "articles": [
            {"title": a.title, "arxiv_id": a.arxiv_id, "canonical_id": a.canonical_id}
            for a in results
        ],
        "truncated": truncated,
    }
    return {"content": [{"type": "text", "text": json.dumps(payload)}]}


@tool(
    "filter_unpublished",
    "READ-ONLY. Given a JSON list of {title, arxiv_id, canonical_id, ...}, "
    "return only the ones NOT already published in a previous run. Does "
    "NOT record anything -- safe to call while drafting, before human "
    "approval. Calling this twice with the same input returns the same "
    "result both times.",
    {"articles_json": str},
)
async def filter_tool(args):
    articles = json.loads(args["articles_json"])
    published = load_published()
    fresh = [a for a in articles if a.get("canonical_id") not in published]
    return {"content": [{"type": "text", "text": json.dumps(fresh)}]}


@tool(
    "publish_digest",
    "The ONLY tool with side effects. Call this ONLY after the human has "
    "approved (this call is additionally gated by a PreToolUse hook that "
    "can deny it outright). Writes the markdown to digest.md AND records "
    "every article in `published_articles_json` as published, so future "
    "runs correctly dedupe them.",
    {"markdown": str, "published_articles_json": str},
)
async def publish_tool(args):
    DIGEST_PATH.parent.mkdir(parents=True, exist_ok=True)
    DIGEST_PATH.write_text(args["markdown"])
    articles = json.loads(args["published_articles_json"])
    try:
        mark_published([
            Article(
                arxiv_id=a.get("arxiv_id", a["canonical_id"]),
                canonical_id=a["canonical_id"],
                title=a["title"],
                published=a.get("published", ""),
                categories=a.get("categories", []),
                summary="",
                topic_tags=a.get("topic_tags", []),
            )
            for a in articles
        ])
    except Exception:
        DIGEST_PATH.unlink(missing_ok=True)
        return {"content": [{"type": "text", "text": (
            "PUBLISH FAILED -- could not record published state; "
            "digest.md rolled back so this run is safe to retry."
        )}], "is_error": True}
    return {"content": [{"type": "text", "text": f"written to {DIGEST_PATH}, {len(articles)} marked published"}]}


arxiv_server = create_sdk_mcp_server(
    name="arxiv-digest-tools",
    version="1.0.0",
    tools=[search_physics_tool, search_math_tool, filter_tool, publish_tool],
)


# ---- hook: intercept publish_digest for human approval -------------------

async def require_approval_hook(input_data, tool_use_id, context):
    """PreToolUse hook: fires before ANY tool call; we only act when the
    tool about to run is our gated publish_digest tool. Blocking here
    (permissionDecision='deny') stops the SDK's own tool execution --
    this is enforced by the harness, not by agent good behavior. Because
    publish_digest is also the ONLY tool that calls mark_published, a
    denial here means state genuinely never gets written -- there's no
    separate mutating call upstream of this gate anymore."""
    tool_name = input_data.get("tool_name", "")
    if not tool_name.endswith("publish_digest"):
        return {}

    markdown = input_data.get("tool_input", {}).get("markdown", "")
    print("\n----- DIGEST PREVIEW -----\n")
    print(markdown)
    answer = input("\nApprove for publishing? [y/N] ").strip().lower()
    if answer == "y":
        return {}  # allow the tool call to proceed
    return {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": "Human rejected the digest.",
        }
    }


# ---- subagent definitions -------------------------------------------------

physics_subagent = AgentDefinition(
    description="Researches recent physics arXiv lecture notes.",
    prompt=(
        f"Use mcp__arxiv-digest-tools__search_physics starting with days=14. "
        f"If you get fewer than {MIN_HITS} hits, call it again doubling "
        f"`days` (cap {MAX_DAYS}), up to 2 retries. Report the final title "
        "list, arxiv_id, canonical_id, topic tags, days window used, retry "
        "count, and the tool's `truncated` flag from your last call (true "
        "means the scan hit its page cap before the window boundary -- "
        "flag the results as possibly incomplete, not exhaustive)."
    ),
    tools=["mcp__arxiv-digest-tools__search_physics"],
    model="sonnet",
)

math_subagent = AgentDefinition(
    description="Researches recent math arXiv lecture notes.",
    prompt=(
        f"Use mcp__arxiv-digest-tools__search_math starting with days=14. "
        f"If you get fewer than {MIN_HITS} hits, call it again doubling "
        f"`days` (cap {MAX_DAYS}), up to 2 retries. Report the final title "
        "list, arxiv_id, canonical_id, days window used, retry count, and "
        "the tool's `truncated` flag from your last call (true means the "
        "scan hit its page cap before the window boundary -- flag the "
        "results as possibly incomplete, not exhaustive)."
    ),
    tools=["mcp__arxiv-digest-tools__search_math"],
    model="sonnet",
)


ORCHESTRATOR_PROMPT = """\
You are building today's arXiv lecture-notes digest.

1. Delegate to the `physics-researcher` subagent and the `math-researcher`
   subagent (via the Task tool) to gather results. Run both.
2. Combine their reported articles into one JSON list and call
   mcp__arxiv-digest-tools__filter_unpublished on it. This is READ-ONLY
   -- it does not record anything, so it is safe to call before you know
   whether the human will approve.
3. Write a Markdown digest with '## Physics' and '## Math' sections,
   listing only the filtered (unpublished) articles (physics entries
   should note their topic tags). If either subagent reported
   truncated=true, add a note under that section saying the search may
   be incomplete (it hit its page-scan cap). Render each article's
   arxiv_id as a clickable Markdown link to its arXiv abstract page,
   e.g. '- **<title>** _(tags: <tags>)_ — [<arxiv_id>](https://arxiv.org/abs/<arxiv_id>)',
   not as bare text.
4. Call mcp__arxiv-digest-tools__publish_digest with that markdown AND
   the SAME filtered article list (so it can record them). This call is
   gated by a human-approval hook -- if it is denied, tell the user the
   digest was not published and that nothing was recorded, so these
   same articles will be reconsidered next run. Do not attempt to call
   publish_digest again after a denial.
"""


async def main():
    options = ClaudeAgentOptions(
        mcp_servers={"arxiv-digest-tools": arxiv_server},
        allowed_tools=[
            "Task",
            "mcp__arxiv-digest-tools__search_physics",
            "mcp__arxiv-digest-tools__search_math",
            "mcp__arxiv-digest-tools__filter_unpublished",
            "mcp__arxiv-digest-tools__publish_digest",
        ],
        agents={
            "physics-researcher": physics_subagent,
            "math-researcher": math_subagent,
        },
        hooks={
            "PreToolUse": [HookMatcher(matcher=None, hooks=[require_approval_hook])],
        },
    )

    async with ClaudeSDKClient(options=options) as client:
        await client.query(ORCHESTRATOR_PROMPT)
        async for message in client.receive_response():
            print(message)


if __name__ == "__main__":
    asyncio.run(main())
