Use your Python kernel to fetch `https://export.arxiv.org/api/query`
with `search_query=cat:quant-ph+OR+cat:hep-th+OR+cat:cond-mat.str-el+OR+cat:cond-mat.mes-hall`,
sorted by submittedDate descending. Fetch in pages of 100
(`start=0,100,200,...`); after each page, check whether the OLDEST
entry in that page (last one, since results are newest-first) is
already older than your current day window -- if so, stop fetching
more pages; otherwise fetch the next page, up to 5 pages total. This
matters because a fixed single page of 100 results means widening the
day window later has no effect if the category has more than 100
submissions in that window -- you have to actually fetch further back,
not just re-filter the same 100.

Track whether you hit the 5-page cap WITHOUT ever reaching an entry
older than your current day window (as opposed to the feed simply
running out, or you reaching the window boundary naturally). If you
hit the cap that way, set `truncated: true` -- it means your scan may
be incomplete, not exhaustive, and the digest should say so rather
than silently presenting a capped scan as a full one. Otherwise
`truncated: false`.

Parse the Atom feed with a real XML parser (not string splitting/regex
-- entity-encoded characters and formatting variations will break
naive parsing). Keep entries published within the last 14 days
(reject a future-dated `published` value -- an entry dated after "now"
is bad data, not a match) whose title or summary contains
lecture-notes phrasing ("lecture notes", "lectures on", "course notes",
"introductory lectures") AND matches at least one of: quantum mechanics
(quantum mechanic/quantum theory/"qm "), QFT (quantum field theor/qft/
field theory), solid state physics (solid state/condensed matter/
many-body/strongly correlated).

For each match, compute `canonical_id` by stripping any trailing
version suffix (`v1`, `v2`, ...) from the arXiv id -- e.g.
`2609.00001v2` -> `2609.00001`. This is the stable identity used for
dedup later; the raw `arxiv_id` (with version) is also worth keeping
for display.

If you end up with fewer than 3 matching articles, double the day
window (cap 60) and retry, up to 2 retries total.

Report back as JSON: `{ "articles": [{"title": ..., "arxiv_id": ...,
"canonical_id": ..., "topic_tags": [...]}], "days_used": <int>,
"retries": <int>, "truncated": <bool> }`.
