/**
 * Pi extension adding a single `arxiv_search` tool.
 *
 * This is the mechanism Pi uses for EVERYTHING beyond its 4-tool core
 * (read/write/edit/bash): a typed TypeScript module registered as a
 * tool, loaded by the CLI at startup. There is no separate "subagent"
 * or "handoff" concept here -- one Pi session, one model, and however
 * many tools you bolt on.
 *
 * --- Revision history -------------------------------------------------
 * v2 fixes, from external code review (mirroring shared/arxiv_client.py):
 *   - Real XML parsing via `fast-xml-parser` instead of regex/string
 *     splitting. The original `xml.split("<entry>")` +
 *     `match(/<title>.../)` approach is brittle against namespace
 *     prefixes, XML entities, CDATA, or any feed formatting change --
 *     and since the whole point of this project is comparing
 *     orchestration, not parsing quality, pi.dev shouldn't be running a
 *     subtly worse arXiv client than the Python implementations.
 *   - HTTP status is checked; a non-200 response (429, 500, an HTML
 *     error page) now throws instead of being silently parsed into
 *     zero results.
 *   - Invalid/missing `published` dates are explicitly checked for NaN
 *     rather than relying on a NaN comparison happening to return
 *     false.
 *   - Date-window check rejects a future-dated entry (mirrors the same
 *     fix in the Python client's `_within_window`).
 *   - `cat:math.*` wildcard replaced with an explicit OR of the ~32 real
 *     math.* arXiv subject-class codes -- same reasoning as the Python
 *     side: this project has no way to verify wildcard category
 *     matching against the live API from the sandbox it was built in,
 *     and a silent partial match would make the Math branch look
 *     structurally fine while quietly returning too few/wrong results.
 *   - Pagination: widening `days` now actually fetches more candidate
 *     pages (fetch until an entry falls older than the window, capped),
 *     instead of re-filtering the same fixed 100 newest submissions --
 *     matches the Python client's `_fetch_entries_for_window` fix.
 *   - Returns a version-stripped `canonicalId` alongside `arxivId`,
 *     matching the Python side's `canonical_id`, since the shared state
 *     store now keys published state by canonical id, not title.
 *
 * v3 fix, from a second external review round:
 *   - `fetchEntriesForWindow` hit its `maxPages` cap (500 entries) and
 *     silently returned whatever it had scanned so far, the same gap
 *     flagged in the Python client. `arxivSearch` now also returns a
 *     `truncated: boolean` flag (true only when the scan exhausted its
 *     page cap without reaching the window boundary), and AGENTS.md
 *     instructs the model to surface it rather than treat a capped
 *     scan as exhaustive -- mirrors the `truncated` tuple element now
 *     returned by `search_physics_lecture_notes`/`search_math_lecture_notes`
 *     in shared/arxiv_client.py.
 *
 * NOTE on the asymmetry this project accepts: pi.dev and omp.sh can't
 * import shared/arxiv_client.py (they aren't Python), so this file is
 * a deliberate reimplementation. Its keyword lists are kept in sync by
 * hand with PHYSICS_TOPIC_KEYWORDS / LECTURE_NOTE_KEYWORDS in
 * shared/arxiv_client.py -- a change to one without the other means
 * the six implementations are comparing different search logic, not
 * just different orchestration. See the top-level README for this
 * called out explicitly rather than left implicit.
 *
 * Install as a Pi package, or drop into ~/.pi/agent/extensions/ per
 * Pi's extension-loading convention. Requires `fast-xml-parser`
 * (`npm install fast-xml-parser`).
 */

import { XMLParser } from "fast-xml-parser";
import type { Extension, ToolDefinition } from "@earendil-works/pi-coding-agent";

const ARXIV_API = "https://export.arxiv.org/api/query";
const PAGE_SIZE = 100;
const MAX_PAGES = 5; // safety cap: 5 * 100 = 500 entries max per search

const PHYSICS_CATEGORIES = [
  "quant-ph",
  "hep-th",
  "cond-mat.str-el",
  "cond-mat.mes-hall",
];

// Explicit math.* subject-class codes -- see revision note above on why
// "cat:math.*" is deliberately NOT used.
const MATH_CATEGORIES = [
  "math.AC", "math.AG", "math.AP", "math.AT", "math.CA", "math.CO",
  "math.CT", "math.CV", "math.DG", "math.DS", "math.FA", "math.GM",
  "math.GN", "math.GR", "math.GT", "math.HO", "math.IT", "math.KT",
  "math.LO", "math.MG", "math.MP", "math.NA", "math.NT", "math.OA",
  "math.OC", "math.PR", "math.QA", "math.RA", "math.RT", "math.SG",
  "math.SP", "math.ST",
];

const LECTURE_KEYWORDS = [
  "lecture note",
  "lecture notes",
  "lectures on",
  "course note",
  "introductory lectures",
];

// Keep in sync with PHYSICS_TOPIC_KEYWORDS in shared/arxiv_client.py
// (including the "qm " entry -- a prior version of this file was
// missing it, which meant pi.dev and the Python implementations were
// silently comparing different search logic).
const PHYSICS_TOPIC_KEYWORDS: Record<string, string[]> = {
  "quantum mechanics": ["quantum mechanic", "quantum theory", "qm "],
  QFT: ["quantum field theor", "qft", "field theory"],
  "solid state physics": ["solid state", "condensed matter", "many-body", "strongly correlated"],
};

interface ArxivEntry {
  title: string;
  arxivId: string;
  published: string;
  summary: string;
}

interface AtomFeed {
  feed?: {
    entry?: unknown; // single object when there's exactly one entry, else an array
  };
}

const xmlParser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  textNodeName: "#text",
});

function asArray<T>(value: T | T[] | undefined): T[] {
  if (value === undefined) return [];
  return Array.isArray(value) ? value : [value];
}

function textOf(node: unknown): string {
  if (node == null) return "";
  if (typeof node === "string") return node;
  if (typeof node === "object" && "#text" in (node as Record<string, unknown>)) {
    return String((node as Record<string, unknown>)["#text"]);
  }
  return String(node);
}

async function fetchAtomPage(searchQuery: string, start: number, pageSize: number): Promise<ArxivEntry[]> {
  const url = `${ARXIV_API}?search_query=${encodeURIComponent(searchQuery)}&start=${start}&max_results=${pageSize}&sortBy=submittedDate&sortOrder=descending`;
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`arXiv request failed: ${res.status} ${res.statusText}`);
  }
  const xml = await res.text();

  const parsed = xmlParser.parse(xml) as AtomFeed;
  const entries = asArray(parsed.feed?.entry);

  return entries.map((entry: any) => {
    const rawId: string = textOf(entry.id);
    const arxivId = rawId.split("/").pop() ?? "";
    const title = textOf(entry.title).replace(/\s+/g, " ").trim();
    const summary = textOf(entry.summary).replace(/\s+/g, " ").trim();
    const published = textOf(entry.published);
    return { title, summary, published, arxivId };
  });
}

/** Strip a trailing version suffix ("v1", "v2", ...) so re-submissions
 * of the same paper dedupe against history correctly -- mirrors
 * canonicalize_id() in shared/arxiv_client.py. */
function canonicalizeId(arxivId: string): string {
  return arxivId.replace(/v\d+$/, "");
}

function parsePublished(publishedIso: string): number | null {
  const t = new Date(publishedIso).getTime();
  return Number.isNaN(t) ? null : t;
}

/** True iff `published` is within [now - days, now]. Explicitly
 * rejects a future-dated entry and an unparseable date, mirroring
 * `_within_window` in shared/arxiv_client.py. */
function withinWindow(publishedIso: string, days: number, now: number): boolean {
  const published = parsePublished(publishedIso);
  if (published === null) return false;
  const ageMs = now - published;
  const windowMs = days * 24 * 60 * 60 * 1000;
  return ageMs >= 0 && ageMs <= windowMs;
}

function matchesAny(text: string, keywords: string[]): boolean {
  const lower = text.toLowerCase();
  return keywords.some((k) => lower.includes(k.toLowerCase()));
}

/**
 * Pages through the (newest-first) feed until an entry falls older
 * than the requested window, instead of only ever inspecting the first
 * `pageSize` newest submissions. Without this, widening `days` from 14
 * to 56 had almost no effect whenever a category publishes more than
 * `pageSize` papers in 60 days -- mirrors
 * `_fetch_entries_for_window` in shared/arxiv_client.py.
 */
async function fetchEntriesForWindow(
  searchQuery: string,
  days: number,
  now: number,
  pageSize: number = PAGE_SIZE,
  maxPages: number = MAX_PAGES,
): Promise<{ entries: ArxivEntry[]; truncated: boolean }> {
  const cutoff = now - days * 24 * 60 * 60 * 1000;
  const all: ArxivEntry[] = [];
  let truncated = true;

  for (let page = 0; page < maxPages; page++) {
    const pageEntries = await fetchAtomPage(searchQuery, page * pageSize, pageSize);
    if (pageEntries.length === 0) {
      truncated = false; // feed ran out on its own -- not a capped scan
      break;
    }
    all.push(...pageEntries);

    const oldestInPage = parsePublished(pageEntries[pageEntries.length - 1].published);
    if (oldestInPage !== null && oldestInPage < cutoff) {
      // Sorted descending by submission date: once one entry in this
      // page is older than the window, every subsequent page is
      // older still. Safe to stop -- we reached the window boundary,
      // not the page cap, so this is NOT a truncated scan.
      truncated = false;
      break;
    }
  }
  // Loop completed all `maxPages` iterations without either exhausting
  // the feed or reaching the window boundary: `truncated` stays true.
  return { entries: all, truncated };
}

async function arxivSearch(args: { category: "physics" | "math"; days: number }) {
  const { category, days } = args;
  const now = Date.now();
  const query =
    category === "physics"
      ? PHYSICS_CATEGORIES.map((c) => `cat:${c}`).join(" OR ")
      : MATH_CATEGORIES.map((c) => `cat:${c}`).join(" OR ");

  const { entries, truncated } = await fetchEntriesForWindow(query, days, now);
  const inWindow = entries.filter((e) => withinWindow(e.published, days, now));

  const articles = [];
  for (const e of inWindow) {
    const blob = `${e.title} ${e.summary}`;
    if (!matchesAny(blob, LECTURE_KEYWORDS)) continue;

    if (category === "physics") {
      const topicTags = Object.entries(PHYSICS_TOPIC_KEYWORDS)
        .filter(([, kws]) => matchesAny(blob, kws))
        .map(([topic]) => topic);
      if (topicTags.length === 0) continue;
      articles.push({ title: e.title, arxivId: e.arxivId, canonicalId: canonicalizeId(e.arxivId), topicTags });
    } else {
      articles.push({ title: e.title, arxivId: e.arxivId, canonicalId: canonicalizeId(e.arxivId), topicTags: [] });
    }
  }

  return { articles, count: articles.length, truncated };
}

const arxivSearchTool: ToolDefinition = {
  name: "arxiv_search",
  description:
    "Search arXiv for lecture-notes-style papers. category is 'physics' " +
    "(quant-ph/hep-th/cond-mat, tagged with quantum mechanics/QFT/solid " +
    "state physics) or 'math' (explicit math.* subject classes). days is " +
    "the recency window. Returns " +
    "{ articles: [{title, arxivId, canonicalId, topicTags}], count, truncated }. " +
    "truncated=true means the scan hit its page cap before reaching the " +
    "window boundary -- treat the results as possibly incomplete, not " +
    "exhaustive.",
  parameters: {
    type: "object",
    properties: {
      category: { type: "string", enum: ["physics", "math"] },
      days: { type: "number" },
    },
    required: ["category", "days"],
  },
  handler: async (args: { category: "physics" | "math"; days: number }) => arxivSearch(args),
};

const extension: Extension = {
  name: "arxiv-digest-tools",
  tools: [arxivSearchTool],
};

export default extension;
