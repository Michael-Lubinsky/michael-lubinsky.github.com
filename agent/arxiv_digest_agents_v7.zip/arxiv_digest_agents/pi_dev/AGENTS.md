# arXiv Lecture Notes Digest — Pi agent instructions

You are running inside Pi, a minimal terminal coding-agent harness whose
built-in tools are exactly: read, write, edit, bash. There is no
multi-agent primitive and no graph in Pi's core -- extensibility comes
from TypeScript extensions (see `arxiv_tools.ts` in this directory) and
from you, the model, sequencing the work yourself inside one session.
This is the point of comparison: everywhere another framework in this
project uses a graph node, a crew role, a handoff, or a subagent, Pi
instead gives you a slightly bigger toolbox and trusts the model's own
planning to sequence the steps.

## Task

Produce `output/digest.md` (create the `output/` subdirectory if it
doesn't exist yet) — the generated digest, deliberately kept in its own
folder and given a plain filename distinct from the instruction files
in `prompts/` (e.g. `prompts/arxiv_digest_prompt.md`), so a generated
artifact is never confusable with a hand-written prompt file that
happens to share a name. An arXiv lecture-notes digest with two
sections.

1. **Physics.** Call the `arxiv_search` tool with
   `category="physics", days=14`. It returns JSON:
   `{ articles: [{title, arxivId, canonicalId, topicTags}], count, truncated }`.
   Only titles whose `topicTags` include at least one of
   `"quantum mechanics"`, `"QFT"`, `"solid state physics"` count.
   If `count < 3`, call it again with `days` doubled (cap at 60),
   up to 2 retries total, before moving on with whatever you have.
   Keep track of the final `truncated` value -- `true` means the scan
   hit its internal page cap before reaching the `days` window
   boundary, so the result may be incomplete rather than exhaustive.

2. **Math.** Same tool with `category="math", days=14`. If
   `count < 3`, retry with doubled `days` (cap 60), up to 2 retries.
   Track its final `truncated` value the same way.

3. **Filter against published history (READ-ONLY -- do not write
   anything yet).** Read `../shared/published.json` with the `read`
   tool if it exists; treat a missing file as `{}`. It is a JSON
   object keyed by `canonicalId` (e.g. `{"2609.00001": {"title": ...,
   "published_at": ...}}`). Drop any article whose `canonicalId` is
   already a key in that object, from both sections. **Do not write to
   `published.json` at this step.** This step must be safe to run
   before you know whether the human will approve the digest -- if you
   write here and the human rejects, those articles would wrongly
   disappear from every future run despite never having been
   published. (An earlier version of this project's every
   implementation had exactly this bug; it's the reason this step is
   spelled out so explicitly.)

4. **Compose.** `write` `output/digest.md` with:
   ```
   # arXiv Lecture Notes Digest

   ## Physics (window: <days> days, <retries> retries)
   - **<title>** _(tags: <tags>)_ — [<arxivId>](https://arxiv.org/abs/<arxivId>)
   ...

   ## Math (window: <days> days, <retries> retries)
   - **<title>** — [<arxivId>](https://arxiv.org/abs/<arxivId>)
   ...
   ```
   Render each article's `arxivId` as a clickable Markdown link to its
   arXiv abstract page as shown above, not as bare text.

   If either section's final `truncated` value was `true`, add a line
   under that section's heading noting the search may be incomplete
   (it hit its page-scan cap before reaching the window boundary) --
   don't let the reader assume a capped scan was exhaustive.

   Keep track of the filtered (unpublished) article list from step 3
   in your own working notes (title, arxivId, canonicalId,
   published-date-if-you-have-it) -- you'll need it again in step 6,
   but only if approved.

5. **Human approval.** Print the digest to the terminal and ask the
   user to type `y` to approve. Pi has no built-in approval primitive
   (no interrupt(), no human_input=True) -- this is a plain question
   in the conversation, gated only by your own instructions, which is
   the honest tradeoff of a minimal harness: you get simplicity, you
   lose an enforced pause.

6. **Only if approved:** leave `output/digest.md` in place, then update
   `published.json`: read it again (it may have changed since step 3
   if another run happened concurrently -- read, don't trust your step
   3 copy), merge in an entry for every article from your step-3
   filtered list under its `canonicalId`
   (`{"title": ..., "published_at": ...}`), and `write` the merged
   object back. This is the ONLY step in this whole task that may
   write to `published.json`. Then say "APPROVED — written to
   output/digest.md, N articles recorded as published".

   Note on partial failure: `output/digest.md` and `published.json` are
   two separate file writes, not one atomic transaction. If the
   `published.json` write fails (e.g. a bash/write tool error) after
   `output/digest.md` was already written, use `bash` to
   `rm output/digest.md` before reporting the failure, so a failed
   publish never leaves a digest on disk describing articles that were
   never actually recorded -- that would risk the same papers being
   republished next run. Report the failure plainly rather than
   guessing whether the write succeeded.

   **If NOT approved:** delete `output/digest.md` with `bash`
   (`rm output/digest.md`) and say "NOT APPROVED — digest discarded,
   published.json left unchanged (these articles will be reconsidered
   next run)". Do not touch `published.json` at all on this path.

Do not fabricate arXiv results if the tool call fails -- report the
failure and stop.
