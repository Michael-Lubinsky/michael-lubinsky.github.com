# pi.dev implementation

Pi has no graph, no crew, no handoff/subagent primitive in its core --
it is deliberately four tools (read/write/edit/bash) plus a system
prompt, with everything else opt-in via TypeScript extensions. So this
"implementation" is:

- `arxiv_tools.ts` — one extension adding a single `arxiv_search` tool
  (physics or math category, date window in, articles out). This is
  the idiomatic Pi way to add a capability: a typed function, nothing
  more.
- `AGENTS.md` — the orchestration logic that in every other framework
  here lives in code (graph edges, task definitions, handoffs, hooks)
  is instead written as instructions for the model to carry out itself
  inside one session: search physics, retry-and-widen if thin, search
  math, retry-and-widen, filter (read-only) against a JSON file it
  reads with its own `read` tool, compose the digest, ask for approval
  as a plain conversational question, and only then `write` both
  `output/digest.md` and the updated published-state file.
- `prompts/arxiv_digest_prompt.md` — a Pi prompt template
  (`/arxiv_digest_prompt`) that kicks the whole thing off. Named for
  its role (an instruction file, not output) and kept in its own
  `prompts/` directory, deliberately distinct from the generated
  `output/digest.md` it produces -- an earlier revision of this project
  had both files literally named `digest.md` in different directories,
  which was confusing to a human skimming the tree and, once, caused a
  cleanup script matching on filename to delete the wrong one.

**Fixed after external review:** the original `AGENTS.md` told the
model to read/write the seen-titles file as one combined "dedupe" step,
before asking for approval -- so a rejected digest still got its
articles recorded as seen and they'd vanish from every future run
despite never being published. Step 3 (filter) and step 6 (record) are
now explicitly separated in `AGENTS.md`, with step 6 gated on
approval -- since Pi has no harness-level enforcement for this (see
below), the fix here is entirely in how explicitly the instructions
spell out the ordering.

## Run

```bash
npm install -g --ignore-scripts @earendil-works/pi-coding-agent
# Register the extension per Pi's extension-loading convention, e.g.
# copy arxiv_tools.ts into ~/.pi/agent/extensions/ or package it as a
# Pi Package -- see https://pi.dev docs for the current mechanism.
cd pi_dev
pi
# then, inside the Pi session:
/arxiv_digest_prompt
```

## What this demonstrates

Pi trusts one model, in one session, with a slightly bigger toolbox, to
sequence multi-step work itself -- no enforced retry edge, no enforced
approval gate, no separate agent processes. That is Pi's whole thesis:
push complexity out of the harness and into either (a) a small
extension or (b) the model's own judgement. You get simplicity and
full auditability of "what actually ran" (it's just tool calls in one
transcript); you lose the structural guarantees LangGraph's conditional
edges or the Claude Agent SDK's PreToolUse hook give you -- here, "must
retry if <3 hits" and "must pause for approval" are both instructions
the model could, in principle, skip. The same is true of "don't record
as published until approved" -- unlike the Claude Agent SDK's
PreToolUse hook (which can literally deny the write) or LangGraph's
`interrupt()` (which suspends the graph until resumed), nothing here
stops the model from writing `published.json` early if it doesn't
follow the instruction. This is a real, honest limitation of the
minimal-harness approach, not something fixable by better wording
alone.
