# Changelog: v5 → v6

User-requested follow-up to v5: the v5 fix moved pi.dev's generated
output to `pi_dev/output/digest.md` but left the other five
implementations writing straight into their own top-level directory
(`langgraph/digest.md`, `crewai/digest.md`, `openai_agents_sdk/digest.md`,
`claude_agent_sdk/digest.md`), and omp.sh's `SYSTEM.md` still instructed
writing plain `digest.md`. Output location was inconsistent across the
six implementations even though the underlying problem (a generated
artifact sharing a name/location with something hand-written) was the
same class of issue everywhere.

**Fix:** Standardized every implementation to `<impl>/output/digest.md`:

- `langgraph/digest_graph.py`'s `publish()`,
  `crewai/digest_crew.py`'s `DIGEST_PATH`,
  `openai_agents_sdk/digest_agents.py`'s `DIGEST_PATH`, and
  `claude_agent_sdk/digest_agent.py`'s `DIGEST_PATH` all now point at
  `<impl>/output/digest.md` instead of `<impl>/digest.md`, each with
  `DIGEST_PATH.parent.mkdir(parents=True, exist_ok=True)` added before
  the write (the `output/` directory isn't checked into the repo, so it
  has to be created on first run).
- `omp_sh/SYSTEM.md` updated the same way pi.dev's `AGENTS.md` was in
  v5: every reference to writing/deleting `digest.md` now reads
  `output/digest.md`, including the rollback-on-failure and
  reject-path deletion instructions.
- Top-level `README.md`'s layout diagram now shows `output/digest.md`
  under every implementation, not just pi.dev.

**Verified:** Confirmed each of the four Python implementations'
`DIGEST_PATH`/`out_path` now resolves to `<impl>/output/digest.md`;
re-ran the `publish()`/`publish_digest`/`publish_tool` success and
rollback-on-failure tests from the v3 changelog entry against the new
path for all four (mkdir-then-write on success, delete-on-failure) and
confirmed both still pass with the file actually landing under
`output/`; grepped `omp_sh/SYSTEM.md` and the top-level `README.md` for
any remaining bare (non-`output/`) `digest.md` path reference implying
a per-implementation write location -- none found.

---

# Changelog: v4 → v5

User-requested cleanups (not from an external review): a confusing
duplicate filename, and a usability improvement to the generated digest
itself.

## 1. `pi_dev/prompts/digest.md` and pi.dev's generated output shared the name "digest.md"

**Was:** `pi_dev/prompts/digest.md` is a Pi prompt template (the
`/digest` slash command) that kicks off the run; the run's actual
*output* was also written as `pi_dev/digest.md`. Two files named
`digest.md` in the same implementation, one hand-written instructions
and one generated content, is confusing to skim and was the direct
cause of a past incident in this project: a cleanup script matched on
the filename `digest.md` to strip generated output before zipping and
deleted the prompt template along with it, because filename matching
alone can't distinguish "input" from "output" when they're named the
same thing.

**Fix:** Renamed the prompt template to `pi_dev/prompts/arxiv_digest_prompt.md`
(slash command is now `/arxiv_digest_prompt`) and moved pi.dev's
generated output to its own `pi_dev/output/digest.md`, so the two are
never named the same thing and never share a directory. `AGENTS.md` and
`README.md` were updated throughout to reference the new paths.

**Verified:** Confirmed `pi_dev/prompts/digest.md` no longer exists and
`pi_dev/prompts/arxiv_digest_prompt.md` does; confirmed every reference
to the old bare `digest.md` path inside `pi_dev/AGENTS.md`,
`pi_dev/README.md`, and `pi_dev/prompts/arxiv_digest_prompt.md` was
updated to `output/digest.md` (grepped for stragglers -- none found).

## 2. Generated digest listed bare arXiv ids instead of clickable links

**Was:** Every implementation's digest rendered each article as
`- **<title>** — <arxiv_id>` (or with a topic-tags aside for physics)
— a plain-text id a reader has to copy-paste into a browser to actually
open the paper.

**Fix:** Every implementation now renders the id as a Markdown link to
the paper's arXiv abstract page:
`[<arxiv_id>](https://arxiv.org/abs/<arxiv_id>)`. For LangGraph (the
one implementation that composes the digest in plain Python rather
than via an LLM following instructions), added `Article.abstract_url`
/ module-level `abstract_url()` to `shared/arxiv_client.py` and used it
directly. For the five LLM-driven implementations (CrewAI, OpenAI
Agents SDK, Claude Agent SDK, pi.dev, omp.sh), updated the instruction
text describing the digest's Markdown format to show the link syntax
explicitly, since those implementations compose the markdown via the
model following instructions rather than fixed code.

**Verified:** `shared/arxiv_client.py`'s `abstract_url()` and
`Article.abstract_url` tested directly against a versioned id
(confirms `https://arxiv.org/abs/2609.00001v2`, i.e. the version
suffix is preserved -- arXiv's abstract page accepts a versioned id
directly). Re-ran the existing LangGraph full-simulated-run test and
confirmed the digest markdown now contains
`[<arxiv_id>](https://arxiv.org/abs/<arxiv_id>)` for every article
instead of a bare id.

---

# Changelog: v3 → v4

A third external review round on `arxiv_digest_agents_v4.zip` (really,
the v3-fixed code) found one important remaining issue in LangGraph.
Verified against the actual v3 code, reproduced end-to-end against the
real `langgraph/digest_graph.py` (not a simplified stand-in), and
fixed.

## 1. LangGraph's fan-in at `merge_and_dedupe` was not actually a barrier — High

**Was:** The v3 comment claimed "`merge_and_dedupe` is a fan-in point
LangGraph waits on until both branches have reached it (superstep
semantics)," based on wiring two separate
`add_conditional_edges(..., {"join": "merge_and_dedupe"})` calls (one
per branch) to the same target node. That claim is wrong. Each
conditional edge fires `merge_and_dedupe` independently the moment
*its own* branch reaches "join" — it does not wait for the other
branch. Because `physics_needs_retry`/`math_needs_retry` can each loop
a different number of times (a widen-retry adds an extra
search→widen→search cycle to only one branch), the two branches
normally reach "join" in *different* supersteps whenever one side
needs to retry and the other doesn't.

Reproduced against the real graph (not a toy example): with physics
needing one widen-retry and math not needing any, `merge_and_dedupe`
fired **twice** — first while physics only had its 14-day (incomplete,
1-hit) results and math already had its full 5-hit results, and again
after physics's retry finished. Worse: the human-approval `interrupt()`
paused on the *first*, incomplete call, so a human approving what they
were shown would have triggered `publish()` against a digest missing
whatever physics turned up on its widen-retry — a real
data-correctness bug, not just a redundant recompute.

**Fix:** `g.add_node("merge_and_dedupe", merge_and_dedupe, defer=True)`.
`defer=True` is LangGraph's built-in node-level fan-in barrier,
purpose-built for exactly this shape (parallel branches of uneven
length, e.g. one containing a retry loop): it holds the node until
there is no more pending work anywhere else in the graph, so both
branches — including however many widen-retries either one needed —
are guaranteed to have finished before it runs. No restructuring into
explicit `*_done` passthrough nodes was needed; `defer=True` on the
existing shared target node is sufficient and is the officially
documented pattern for this scenario. The stale comment claiming plain
multi-edge convergence was already a barrier was rewritten to explain
why it wasn't, and why `defer=True` is what actually makes it one.

**Verified:** Reproduced the bug directly against `langgraph/digest_graph.py`
(not a simplified stand-in) by mocking `search_physics_lecture_notes`
to return 1 hit at `days=14` (triggering a retry) and 5 hits at
`days=28`, and `search_math_lecture_notes` to always return 5 hits
(no retry needed) — confirmed, pre-fix, that `merge_and_dedupe` ran
twice, that the human-approval interrupt fired on the first
(incomplete: `physics_results_len=1`) call, and that a mocked
`publish()` in an isolated full-shape repro executed against that
stale, incomplete digest before the second, correct call ever ran.
Post-fix (`defer=True`), re-ran the identical scenario against the
real graph and confirmed `merge_and_dedupe` now runs exactly once,
only after both branches (including the physics retry loop) finish,
with `physics_results_len == 5` and `math_results_len == 5`, and that
the digest preview shown at the human-approval interrupt is
byte-identical to what `merge_and_dedupe` actually produced.

---

# Changelog: v2 → v3

A second external review round on `arxiv_digest_agents_v3.zip` confirmed
all 12 v1→v2 findings were fixed, but flagged two remaining problems
(one High, one Medium/High) plus a smaller transactional nuance and a
pagination-truncation nuance. All four verified against the actual v2
code and fixed below, using the same standard: "Verified" means an
offline, mocked (or, for the concurrency fix, genuinely multi-process)
test was written and run in this environment, not just that the code
looks right.

## 1. `mark_published()` is atomic against corruption, but not against a concurrent read-modify-write race — Medium/High

**Was:** `shared/state_store.py`'s v2 comment claimed temp-file +
`os.replace()` meant "two runs racing can't silently drop one's
update." That's not true: `os.replace()` only makes a single *write*
atomic (no truncated/corrupt file from a crash mid-write). It does
nothing to protect the surrounding read-modify-write *transaction*.
Two concurrent callers could still interleave as:

```
Process A                 Process B
read {X}
                           read {X}
add A
                           add B
write {X,A}
                           write {X,B}   <-- A's update silently lost
```

**Fix:** Added a `_locked()` context manager using `fcntl.flock` (POSIX
advisory, exclusive) on a sidecar `published.json.lock` file.
`mark_published()` now holds that lock across its entire
read+merge+write, so a second concurrent call blocks until the first
finishes rather than racing it. The module docstring was rewritten to
correctly distinguish what atomic writes protect (corruption) from
what they don't (concurrent lost updates), and documents this as a
single-machine POSIX-`flock` fix — genuinely concurrent multi-host
publishing would still want a real database (e.g. SQLite with
`INSERT ... ON CONFLICT DO NOTHING`).

**Verified:** Two tests. (1) A 50-process `multiprocessing` stress
test, each process calling `mark_published()` with a distinct article
concurrently against the same file — confirmed all 50 articles present
afterward, zero lost. (2) A control test reproducing the OLD unlocked
pattern with an injected 0.05s sleep between read and write under
identical concurrent load — confirmed it loses 9 of 10 concurrent
updates, proving both that the reviewed bug was real and that the lock
actually fixes it (not just "looks safe").

## 2. CrewAI's approval gate was LLM-mediated, not enforced — High

**Was:** The v2 fix moved the file write and `mark_published()` call
into a `publish_digest` tool and told the Editor agent, via
`Task(human_input=True)` and plain-text instructions, to "only call
this after approval." But `human_input=True` is a CrewAI task-level
feedback mechanism — it is not a permission gate on a specific tool
call. The Editor agent still *held* the mutating tool at all times; the
only thing stopping an early or duplicate call was the LLM correctly
following its instructions. That's a materially weaker guarantee than,
e.g., the Claude Agent SDK's `PreToolUse` hook, which can
programmatically deny the tool call itself regardless of what the
model "intends."

**Fix:** Removed the mutating capability from the agent entirely
instead of trying to gate it better. `editor_task` now returns a
structured `DigestDraft` (`output_pydantic=DigestDraft`) containing the
composed markdown and the exact article list; the Editor's `tools=`
list is reduced to `filter_unpublished_titles` only (read-only) —
`publish_tool` was deleted as an agent-callable tool entirely. The
actual approval prompt (`input()`) and the actual publish (file write +
`mark_published`) now happen in `__main__`, in plain host-side Python,
completely outside any agent's control. There is no longer any path,
correct instruction-following or not, by which the LLM can call
"publish" — so there's nothing left for it to get wrong.
`Task(human_input=True)` was removed since it was redundant with (and
could be confused for) the real, host-enforced gate.

**Verified:** Confirmed `editor.tools == ['filter_unpublished_titles']`
(no publish tool present at all); confirmed
`editor_task.output_pydantic is DigestDraft` and
`editor_task.human_input is False`; called the new host-side `publish()`
function directly and confirmed it writes `digest.md` and calls
`mark_published` correctly on success, and rolls back correctly on
simulated failure (see #3 below).

## 3. digest.md write + mark_published() aren't a single atomic operation — Medium (mitigated)

**Was:** Several implementations did `DIGEST_PATH.write_text(...)`
immediately followed by `mark_published(...)` as two separate,
unguarded steps. If the second step failed after the first succeeded,
`digest.md` would be left on disk describing articles that were never
actually recorded as published, risking the same papers being
republished (and the digest re-emitted) on the next run.

**Fix:** This isn't a true multi-file transaction (that would need a
real database, as the reviewer noted) — but the specific failure mode
called out is now closed with a rollback-on-failure pattern applied to
every implementation that performs this write pair: if
`mark_published()` raises, the just-written `digest.md` is deleted
(`unlink(missing_ok=True)`) and the failure is surfaced loudly (an
exception in LangGraph/CrewAI, an `is_error` tool result in Claude
SDK, an error string in OpenAI SDK) rather than left as a silent
inconsistency. A failed publish is now always safe to simply retry,
since neither side effect survives a failed attempt. Applied to
`langgraph/digest_graph.py`'s `publish()`, `crewai/digest_crew.py`'s
`publish()`, `openai_agents_sdk/digest_agents.py`'s `publish_digest`
tool, and `claude_agent_sdk/digest_agent.py`'s `publish_tool`; the
instruction-driven `pi_dev/AGENTS.md` and `omp_sh/SYSTEM.md` now
explicitly tell the model to delete `digest.md` if the
`published.json` write fails.

**Verified:** For each of the four Python implementations, simulated a
`mark_published` failure (monkeypatched to raise) after a successful
`digest.md` write, and confirmed `digest.md` is deleted and the
failure is surfaced in each implementation's own idiom (exception /
`is_error` / error-string return).

## 4. Pagination cap can silently pass off a capped scan as exhaustive — Medium

**Was:** `_fetch_entries_for_window()`'s `MAX_PAGES = 5` (500-entry)
safety cap meant a sufficiently active category/window could stop
scanning before reaching the actual date cutoff, with no signal to the
caller that the result might be incomplete — a 500-entry capped scan
and a genuinely exhaustive 30-entry scan looked identical to callers.

**Fix:** `_fetch_entries_for_window()` (Python), `search_physics_tool`/
`search_math_tool` (Claude SDK MCP tools), `search_physics`/
`search_math` (OpenAI SDK function tools and CrewAI tools),
`fetchEntriesForWindow`/`arxivSearch` (TypeScript), and the
instruction-driven `omp_sh` researcher prompts all now return/report an
explicit `truncated: bool` — true only when the scan hit its page cap
*without* the feed running out or reaching the window boundary
naturally. Every orchestrator/agent surfaces it in the final digest as
a caveat note under the relevant section rather than silently treating
a capped scan as exhaustive. `SpecialistReport` (OpenAI SDK) and
`DigestDraft` (CrewAI) both gained a `truncated` field so it survives
the trip from tool call to final structured output.

**Verified:** Per implementation — a mocked multi-page feed test
distinguishing "exhausted naturally" (`truncated=False`) from
"hit the page cap" (`truncated=True`) in `shared/arxiv_client.py`
directly; a full simulated LangGraph run confirming the warning line
appears in the digest markdown; CrewAI's `search_physics_tool`
returning `truncated: True` correctly in its JSON payload; the OpenAI
SDK's `search_physics`/`search_math` tools returning a
`SearchToolResult(truncated=...)` correctly for both a capped and a
non-capped mocked scan; the Claude SDK's `search_physics_tool`/
`search_math_tool` handlers returning the same via their MCP JSON
payload; and, for pi.dev, both a `tsc --noEmit` typecheck and a mocked
runtime test (a physics feed that always returns full pages up to
`MAX_PAGES` → `truncated: true`; a math feed with one entry that runs
out naturally → `truncated: false`).

## Corrected claim

The v1→v2 changelog and README previously stated (of `os.replace()`)
that it meant "two runs racing can't silently drop one's update." That
claim was incorrect, as issue #1 above details, and has been corrected
in both `shared/state_store.py`'s docstring and the README.

---

# Changelog: v1 → v2

All 12 numbered findings from an external code review, plus the
architectural-inconsistency note, verified against the actual v1 code
and fixed. "Verified" below means an offline, mocked test was written
and run in this environment to prove the fix — not just that the code
compiles.

## 1. "Seen" state updated before human approval — High

**Was:** `merge_and_dedupe()` (LangGraph) called `save_seen(new_seen)`
before `human_approval()`; CrewAI's `dedupe_tool`, OpenAI's
`dedupe_and_record`, and Claude SDK's `dedupe_tool` did the same.
Rejecting a digest still recorded its articles as seen, so they
silently vanished from every future run despite never being published.

**Fix:** `shared/state_store.py` now exports `filter_unpublished`
(read-only) and `mark_published` (the only writer, called once, only
on the approved path, alongside the actual `digest.md` write). The old
combined API was deleted, not kept alongside, so nothing can
accidentally import the old mutating call. Every framework
implementation was restructured around this split.

**Verified:** `shared/state_store.py` standalone test (reject → file
absent → same articles reappear next call → approve → persisted →
excluded on next call → version-bumped resubmission still dedupes).
Repeated as a full simulated run through the compiled LangGraph graph,
and against the CrewAI/OpenAI SDK/Claude SDK tool functions directly.

## 2. CrewAI writes the digest even after rejection — High

**Was:** `out_path.write_text(str(result))` ran unconditionally at the
bottom of the script regardless of what the human answered.

**Fix:** The file write moved entirely inside a new `publish_digest`
tool, which the Editor agent is instructed to call only on approval.
The bottom of the script now only logs the crew's summary; it does not
write `digest.md` itself.

**Verified:** Called `publish_tool.func(...)` directly and confirmed
`digest.md` and the published-state file are both absent until that
call happens; confirmed `filter_tool.func(...)` never creates either
file.

## 3. OpenAI Agents orchestration via handoffs is conceptually wrong — High

**Was:** The orchestrator used `handoffs=[physics_agent, math_agent]`
and an instruction to "hand off to both". A handoff *transfers*
control to the target agent; it does not fan out to two agents and
return control to the orchestrator with both results.

**Fix:** Removed `handoffs` entirely. `main()` now calls
`asyncio.gather(Runner.run(physics_agent, ...), Runner.run(math_agent,
...))` directly, then a separate `Runner.run(editor_agent, ...)` call
for the merge/approve/publish step — the orchestrator explicitly
regains control with both results.

**Verified:** Timed the `asyncio.gather` call against two mocked
0.2s-sleep coroutines; measured ~0.2s wall time (would be ~0.4s if
sequential), confirming genuine concurrency, and confirmed both
results land back in one place.

## 4. The OpenAI guardrail doesn't actually implement retry — High

**Was:** `output_guardrail` set `tripwire_triggered=True` when results
were thin, but nothing ever caught the resulting
`OutputGuardrailTripwireTriggered` exception — the run just failed.

**Fix:** Added `run_specialist_with_retry`, which calls `Runner.run`,
catches the tripwire exception, reads the tentative (failing) output's
`days_used`/`hit_count` off `exc.guardrail_result.agent_output`,
doubles the window, and reruns — up to `MAX_RETRIES` times.

**Verified:** Mocked `Runner.run` to raise the tripwire twice (at
days=14 and days=28) then succeed at days=56; confirmed the actual
call sequence was `[14, 28, 56]` and the final report was returned
correctly.

## 5. Deduplication by exact title is fragile — Medium

**Was:** Every implementation checked `if title not in seen`. A minor
title reword ("An Introduction to QFT" vs "...: Lecture Notes") would
dodge dedup entirely, despite `Article.arxiv_id` already existing as a
stable identifier.

**Fix:** Added `canonicalize_id()` (strips a trailing `v\d+` version
suffix) and `Article.canonical_id`. `shared/state_store.py` now keys
its store by `canonical_id`, storing `{title, published_at}` per the
review's suggested shape.

**Verified:** A `v1` article marked published; a `v2` resubmission of
the same paper correctly excluded by `filter_unpublished` via matching
`canonical_id`.

## 6. `seen_titles.json` has no atomic/concurrent update protection — Medium

**Was:** `path.write_text(json.dumps(...))` — a crash mid-write could
leave a truncated/corrupt file, and two concurrent runs could silently
drop one's update.

**Fix:** `mark_published` now writes via `tempfile.mkstemp` +
`os.replace` (atomic on POSIX). `load_published` also treats a corrupt
file as empty rather than raising, so a pre-fix corrupt file left over
doesn't crash every subsequent run.

**Verified:** Inspected the implementation directly; the atomic-replace
pattern is standard and was exercised (without fault injection) in
every other test in this changelog that calls `mark_published`.

## 7. `_within_window()` accepts future dates — Low/Medium

**Was:** `(now - published) <= timedelta(days=days)` is `True` for a
future-dated `published` (negative age), since a negative number is
always `<=` a positive one.

**Fix:** `dt.timedelta(0) <= age <= dt.timedelta(days=days)` — age must
be non-negative too. Same fix applied to the TypeScript client
(`ageMs >= 0 && ageMs <= windowMs`).

**Verified:** An entry dated 3 days in the future against a 14-day
window correctly rejected, in both the Python and TypeScript
implementations; a legitimately recent entry still accepted.

## 8. TypeScript doesn't check HTTP status — Medium

**Was:** `const res = await fetch(url); const xml = await res.text();`
— a 429/500/HTML response would be silently parsed into zero papers.

**Fix:** `if (!res.ok) throw new Error(...)` before parsing.

**Verified:** A mocked `{ok: false, status: 429, ...}` response
correctly throws with a descriptive message.

## 9. Regex/XML parsing in the TypeScript implementation is brittle — Medium

**Was:** `xml.split("<entry>")` + `match(/<title>.../)` — fragile
against namespace prefixes, entities, CDATA, or feed formatting
changes; also meant pi.dev was silently running a lower-quality arXiv
client than the Python implementations for a project explicitly about
comparing orchestration, not parsing.

**Fix:** Replaced with `fast-xml-parser` (added as a real dependency in
`pi_dev/package.json`).

**Verified:** Parsed a mock feed containing an HTML entity (`&amp;`)
and a version-suffixed ID; confirmed the entity decoded correctly
(`&amp;` → `&`) and the ID parsed correctly — both would have needed
extra regex-escaping logic under the old approach.

## 10. Invalid dates in TypeScript can accidentally pass filtering — Medium

**Was:** `new Date(publishedIso).getTime()` returns `NaN` for an
invalid string; the surrounding comparison happened to return `false`,
but not explicitly.

**Fix:** `parsePublished()` explicitly checks `Number.isNaN(t)` and
returns `null`; callers check for `null` rather than relying on NaN
comparison semantics.

**Verified:** `parsePublished("not-a-date")` and `parsePublished("")`
both return `null` directly.

## 11. `math.*` deserves verification — Medium

**Was:** `cat:math.*` used as a wildcard in both the Python and
TypeScript clients, untested against the live API (this sandbox has no
network access to `export.arxiv.org`).

**Fix:** Replaced with an explicit `OR` of the 32 real math.*
subject-class codes (`math.AC`, `math.AG`, ..., `math.ST`) in both
`shared/arxiv_client.py`'s `MATH_CATEGORIES` and
`pi_dev/arxiv_tools.ts`'s `MATH_CATEGORIES`, and spelled out
explicitly in `omp_sh/prompts/math_researcher.md` for the
instruction-driven implementations.

**Verified:** Confirmed no implementation still references `math.*`;
confirmed the Python list has exactly 32 entries.

## 12. Search can miss qualifying papers when widening — Medium

**Was:** Every search fetched a fixed `max_results=100`, sorted
newest-first, then filtered locally. Widening `days: 14 → 28 → 56` had
almost no effect whenever a category published more than 100 papers in
60 days, since every request just re-fetched and re-filtered the same
100 newest submissions.

**Fix:** `_fetch_entries_for_window()` (Python) / `fetchEntriesForWindow()`
(TypeScript) now paginate: fetch pages of 100, and after each page,
stop only once the oldest entry in that page falls older than the
requested window (results are sorted newest-first, so this is a safe
early-exit) — capped at 5 pages (500 entries) as a safety limit. A
wider window now genuinely causes more pages to be fetched.

**Verified:** Mocked a two-page feed (page 0: days 1–100 old, page 1:
days 101–200 old). Confirmed `days=14` fetches only page 0 (`[0]`) and
`days=150` fetches both pages (`[0, 100]`) — in both the Python and
TypeScript implementations independently.

## Architectural inconsistency: pi.dev's separate client

**Was:** The README claimed `shared/arxiv_client.py` was "identical
everywhere," but pi.dev necessarily runs its own TypeScript
reimplementation with slightly different keyword lists (missing the
`"qm "` entry in `quantum mechanics`).

**Fix:** Synced the TypeScript keyword lists exactly with the Python
side, and the top-level README now explicitly documents this as an
accepted, hand-maintained exception rather than leaving it implied by
omission.

## One design change applied throughout

Every fix above followed the review's suggested reframing: separate
**discovery state** from **published state**, with exactly one
function (`mark_published`) allowed to write, called only after a real
approval:

```
research agents -> Candidate[]
      -> filter_unpublished()  (read-only)
      -> DigestDraft
      -> HUMAN APPROVAL
         reject -> stop (no state change)
         approve -> write digest.md -> mark_published()
```
