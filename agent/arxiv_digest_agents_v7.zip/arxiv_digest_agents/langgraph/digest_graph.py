"""
LangGraph implementation of the arXiv lecture-notes digest agent.

What this is meant to demonstrate about LangGraph specifically:
  - An explicit STATE GRAPH: nodes and conditional edges you can draw.
  - Parallel fan-out (physics + math search nodes run off the same
    entry point) then fan-in at a merge node.
  - A CONDITIONAL EDGE that decides "retry with a wider window" vs.
    "move on" based on the shared state -- not a bare while-loop
    buried in a function.
  - A CHECKPOINTER (MemorySaver here; swap for SqliteSaver/Postgres in
    prod) so "published" state persists across runs of the same
    thread, and an `interrupt()` for the human-approval step, which
    LangGraph treats as a first-class graph pause/resume, not an ad
    hoc `input()`.

Fixed after external review: `merge_and_dedupe` previously called
`save_seen()` (writing state) BEFORE `human_approval`. That meant
rejecting a digest still recorded its articles as "seen", so they'd
silently vanish from every future run despite never having been
published. State is now only written in `publish`, after approval,
via the read-only `filter_unpublished` / write-only `mark_published`
split in shared/state_store.py.

Run:
    pip install langgraph
    python digest_graph.py
"""
from __future__ import annotations

import sys
import pathlib
from typing import TypedDict

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from shared.arxiv_client import (
    search_physics_lecture_notes,
    search_math_lecture_notes,
    Article,
)
from shared.state_store import load_published, filter_unpublished, mark_published

from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import interrupt, Command

MIN_HITS = 3
MAX_DAYS = 60
MAX_RETRIES = 2


class DigestState(TypedDict):
    days: int
    physics_days: int
    math_days: int
    physics_attempts: int
    math_attempts: int
    physics_results: list[dict]
    math_results: list[dict]
    physics_truncated: bool   # True if the last search hit the page cap before the window boundary
    math_truncated: bool
    physics_fresh: list[dict]   # candidates not yet published, computed at merge time
    math_fresh: list[dict]
    digest_markdown: str
    approved: bool


# ---- nodes -----------------------------------------------------------

def search_physics(state: DigestState) -> dict:
    days = state.get("physics_days", state["days"])
    results, truncated = search_physics_lecture_notes(days=days)
    return {
        "physics_results": [a.to_dict() for a in results],
        "physics_days": days,
        "physics_truncated": truncated,
    }


def search_math(state: DigestState) -> dict:
    days = state.get("math_days", state["days"])
    results, truncated = search_math_lecture_notes(days=days)
    return {
        "math_results": [a.to_dict() for a in results],
        "math_days": days,
        "math_truncated": truncated,
    }


def widen_physics(state: DigestState) -> dict:
    new_days = min(state["physics_days"] * 2, MAX_DAYS)
    return {
        "physics_days": new_days,
        "physics_attempts": state.get("physics_attempts", 0) + 1,
    }


def widen_math(state: DigestState) -> dict:
    new_days = min(state["math_days"] * 2, MAX_DAYS)
    return {
        "math_days": new_days,
        "math_attempts": state.get("math_attempts", 0) + 1,
    }


def merge_and_dedupe(state: DigestState) -> dict:
    """READ-ONLY with respect to persisted state: only calls
    filter_unpublished (never mark_published). This node runs before
    human approval, so nothing here may commit to disk yet."""
    published = load_published()
    physics_fresh = filter_unpublished(
        [Article(**a) for a in state["physics_results"]], published
    )
    math_fresh = filter_unpublished(
        [Article(**a) for a in state["math_results"]], published
    )

    lines = ["# arXiv Lecture Notes Digest\n"]
    lines.append(f"## Physics (window: {state['physics_days']} days, "
                 f"{state.get('physics_attempts', 0)} widen-retries)\n")
    if state.get("physics_truncated"):
        lines.append("_(search hit the page-scan cap before reaching the window "
                      "boundary -- results below may be incomplete, not exhaustive)_\n")
    if physics_fresh:
        for a in physics_fresh:
            lines.append(f"- **{a.title}** _(tags: {', '.join(a.topic_tags)})_ — "
                         f"[{a.arxiv_id}]({a.abstract_url})")
    else:
        lines.append("- (no new qualifying articles)")

    lines.append(f"\n## Math (window: {state['math_days']} days, "
                 f"{state.get('math_attempts', 0)} widen-retries)\n")
    if state.get("math_truncated"):
        lines.append("_(search hit the page-scan cap before reaching the window "
                      "boundary -- results below may be incomplete, not exhaustive)_\n")
    if math_fresh:
        for a in math_fresh:
            lines.append(f"- **{a.title}** — [{a.arxiv_id}]({a.abstract_url})")
    else:
        lines.append("- (no new qualifying articles)")

    return {
        "digest_markdown": "\n".join(lines),
        "physics_fresh": [a.to_dict() for a in physics_fresh],
        "math_fresh": [a.to_dict() for a in math_fresh],
    }


def human_approval(state: DigestState) -> dict:
    """LangGraph's `interrupt()` pauses the graph and surfaces a value
    to whatever is driving it (CLI, web app, etc.); resuming requires
    a Command(resume=...). This is the graph-native human-in-the-loop
    primitive -- the graph run genuinely suspends, not just "prompt in
    a function"."""
    decision = interrupt(
        {
            "question": "Approve this digest for publishing?",
            "digest_preview": state["digest_markdown"],
        }
    )
    return {"approved": bool(decision)}


def publish(state: DigestState) -> dict:
    """The ONLY node that touches persisted state, and only on the
    approved path -- this is what actually fixes the reviewed bug.

    Note on the write itself: writing digest.md and calling
    mark_published() are two separate operations, not one atomic
    transaction (a true transaction would need e.g. SQLite). If
    mark_published() fails after digest.md was already written, we
    roll digest.md back out and raise, rather than leaving a digest
    file on disk whose articles were never actually recorded as
    published -- that would cause them to be re-offered AND
    re-published next run, silently duplicating the digest. A failure
    here is loud (an exception) rather than a silent inconsistency;
    the run can simply be retried, since neither side effect survives
    a failed attempt."""
    out_path = pathlib.Path(__file__).parent / "output" / "digest.md"
    if state["approved"]:
        newly_published = [Article(**a) for a in state["physics_fresh"]] + \
                           [Article(**a) for a in state["math_fresh"]]
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(state["digest_markdown"])
        try:
            mark_published(newly_published)
        except Exception:
            out_path.unlink(missing_ok=True)
            print("PUBLISH FAILED -- could not record published state; "
                  "digest.md rolled back so this run is safe to retry.")
            raise
        print(f"APPROVED -- digest written to {out_path}, "
              f"{len(newly_published)} articles marked published")
    else:
        print("NOT APPROVED -- digest discarded, no state changed "
              "(these articles will be reconsidered next run)")
    return {}


# ---- conditional edges -------------------------------------------------

def physics_needs_retry(state: DigestState) -> str:
    attempts = state.get("physics_attempts", 0)
    if len(state["physics_results"]) < MIN_HITS and attempts < MAX_RETRIES \
            and state["physics_days"] < MAX_DAYS:
        return "widen_physics"
    return "join"


def math_needs_retry(state: DigestState) -> str:
    attempts = state.get("math_attempts", 0)
    if len(state["math_results"]) < MIN_HITS and attempts < MAX_RETRIES \
            and state["math_days"] < MAX_DAYS:
        return "widen_math"
    return "join"


# ---- graph assembly ------------------------------------------------------

def build_graph():
    g = StateGraph(DigestState)

    g.add_node("search_physics", search_physics)
    g.add_node("search_math", search_math)
    g.add_node("widen_physics", widen_physics)
    g.add_node("widen_math", widen_math)
    # defer=True: see the "merge_and_dedupe" comment below for why this
    # is load-bearing, not cosmetic.
    g.add_node("merge_and_dedupe", merge_and_dedupe, defer=True)
    g.add_node("human_approval", human_approval)
    g.add_node("publish", publish)

    # Fan-out: both searches start from the graph entry point.
    g.set_entry_point("search_physics")
    g.add_edge("__start__", "search_math")  # parallel branch

    # Each branch conditionally loops back to widen its own window.
    g.add_conditional_edges(
        "search_physics", physics_needs_retry,
        {"widen_physics": "widen_physics", "join": "merge_and_dedupe"},
    )
    g.add_edge("widen_physics", "search_physics")

    g.add_conditional_edges(
        "search_math", math_needs_retry,
        {"widen_math": "widen_math", "join": "merge_and_dedupe"},
    )
    g.add_edge("widen_math", "search_math")

    # merge_and_dedupe is a fan-in point, but two independent
    # add_conditional_edges(..., {"join": "merge_and_dedupe"}) calls do
    # NOT by themselves make it wait for both branches -- that was
    # wrong in an earlier version of this comment/file. Each edge
    # fires it independently the moment ITS OWN branch reaches "join",
    # and because physics_needs_retry/math_needs_retry can loop a
    # different number of times per branch, the two branches usually
    # reach "join" in different supersteps. Without defer=True above,
    # merge_and_dedupe (and everything downstream of it, including the
    # human-approval interrupt and publish) can run on a superstep
    # where only ONE branch has actually finished -- verified: a
    # branch needing one widen-retry causes merge_and_dedupe to fire
    # once with the other (finished) branch's real results and the
    # retrying branch's still-incomplete results, then AGAIN once the
    # retry finishes -- and publish() had already run against the
    # first, incomplete digest by the time the second call happened.
    # `defer=True` (LangGraph's node-level fan-in barrier, meant
    # exactly for branches of uneven length such as a retry loop) is
    # what actually makes this a single, correct join: it holds
    # merge_and_dedupe until there is no more pending work anywhere
    # else in the graph, i.e. until BOTH retry loops have finished.
    g.add_edge("merge_and_dedupe", "human_approval")
    g.add_edge("human_approval", "publish")
    g.add_edge("publish", END)

    checkpointer = MemorySaver()
    return g.compile(checkpointer=checkpointer)


if __name__ == "__main__":
    graph = build_graph()
    config = {"configurable": {"thread_id": "arxiv-digest-daily"}}

    initial_state: DigestState = {
        "days": 14,
        "physics_days": 14,
        "math_days": 14,
        "physics_attempts": 0,
        "math_attempts": 0,
        "physics_results": [],
        "math_results": [],
        "physics_truncated": False,
        "math_truncated": False,
        "physics_fresh": [],
        "math_fresh": [],
        "digest_markdown": "",
        "approved": False,
    }

    result = graph.invoke(initial_state, config=config)

    # graph paused at interrupt(); result contains the interrupt payload
    if "__interrupt__" in result:
        payload = result["__interrupt__"][0].value
        print(payload["digest_preview"])
        answer = input("\nApprove? [y/N] ").strip().lower() == "y"
        final = graph.invoke(Command(resume=answer), config=config)
        print(final)
