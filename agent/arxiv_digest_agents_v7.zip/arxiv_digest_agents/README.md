# arXiv Lecture Notes Digest — six framework implementations

Same task, six harnesses/frameworks, so the differences show up in
**how work is structured**, not in what the task does.

## v6 — uniform output layout

A follow-up to v5's pi.dev rename, pointing out the same fix hadn't
been applied everywhere: the other five implementations still wrote
their generated digest straight into their own top-level directory
(`langgraph/digest.md`, `crewai/digest.md`, etc.), while pi.dev alone
used `pi_dev/output/digest.md`. Standardized all six to
`<impl>/output/digest.md`, so "where does the generated file for
implementation X land" has one uniform answer instead of "usually
`<impl>/digest.md`, except pi.dev." See `CHANGELOG.md` for the full
detail.

## v5 — usability cleanups

Two user-requested fixes, not from an external review; see
`CHANGELOG.md` for the full detail.

- **pi.dev had two files named `digest.md`.** `pi_dev/prompts/digest.md`
  (the prompt template) and pi.dev's generated `digest.md` shared a
  filename across different directories -- confusing to skim, and the
  actual cause of a past incident where a cleanup script matching on
  filename deleted the prompt template while trying to strip generated
  output. Renamed the prompt to `pi_dev/prompts/arxiv_digest_prompt.md`
  (slash command `/arxiv_digest_prompt`) and moved the generated output
  to its own `pi_dev/output/digest.md`.
- **Every digest now links straight to arXiv.** Each article's id used
  to render as bare text (`— 2609.00001`); it now renders as a
  clickable Markdown link to the paper's abstract page
  (`[2609.00001](https://arxiv.org/abs/2609.00001)`), across all six
  implementations.

## v4 — third external review and fix

A third review round found one remaining issue, in LangGraph. See
`CHANGELOG.md` for the full before/after and verification.

- **`merge_and_dedupe`'s fan-in wasn't actually a barrier.** Two
  separate `add_conditional_edges(..., {"join": "merge_and_dedupe"})`
  calls — one per research branch — do **not** make LangGraph wait for
  both branches; each fires the shared target independently the moment
  its own branch reaches "join". Since a widen-retry adds an extra
  loop to only one branch, the two branches normally reach "join" in
  different supersteps whenever one needs to retry and the other
  doesn't. Reproduced directly against the real graph: `merge_and_dedupe`
  ran twice — once prematurely, while physics still only had its
  first (thin) attempt and math was already done — and the
  human-approval `interrupt()` paused on that first, incomplete call,
  so an approving human would have triggered `publish()` against a
  digest missing whatever the retry turned up. Fixed with
  `add_node("merge_and_dedupe", merge_and_dedupe, defer=True)` —
  LangGraph's built-in node-level fan-in barrier, purpose-built for
  parallel branches of uneven length (exactly this shape). Verified by
  re-running the identical reproduction post-fix and confirming
  `merge_and_dedupe` now runs exactly once, only after both branches
  (including the retry loop) finish, and that the interrupt preview
  matches what actually gets published.

## v2 — external code review and fixes

A thorough external review of v1 found 12 concrete issues plus one
architectural inconsistency. All 12 were confirmed against the actual
code and fixed; the four marked "High" were the ones that mattered
most and are described in detail below. See `CHANGELOG.md` for the
complete list with before/after and how each was verified.

**The most important bug (found in all six implementations):** the
"dedupe against previous runs" step also *recorded* articles as seen,
and it ran before human approval. Reject a digest, and its articles
still vanished from every future run, despite never actually being
published. Fixed by splitting persisted state into two operations that
never happen in the same call:

```
research agents
      |
Candidate[]
      |
filter_unpublished()   <-- READ-ONLY, safe to call while drafting
      |
DigestDraft
      |
  HUMAN APPROVAL
   /          \
reject       approve
  |             |
 stop      write digest.md
              |
        mark_published()   <-- the ONLY function that writes state,
                                called only after a real, approved
                                publish action
```

`shared/state_store.py` now enforces this shape directly: it exports
`load_published`, `filter_unpublished` (read-only), and
`mark_published` (the only writer) — the old combined
`load_seen`/`save_seen`/`dedupe_against_seen` API was deleted outright
rather than kept alongside, specifically so nothing could silently
import the old mutating call and reintroduce the bug. Every framework
implementation was updated to route through this shape; see
`CHANGELOG.md` for how each one now enforces (or, for pi.dev/omp.sh,
merely instructs) the ordering.

Three other high-severity fixes:
- **CrewAI** used to write `digest.md` unconditionally at the bottom
  of the script regardless of the human's answer. The file write now
  only happens inside a `publish_digest` tool the Editor agent must
  choose to call.
- **OpenAI Agents SDK** used `handoffs=[...]` to fan out to two
  specialists, but a handoff *transfers* control — it doesn't fan out
  and return. Replaced with explicit `asyncio.gather(Runner.run(...),
  Runner.run(...))`, which is genuinely parallel and genuinely returns
  both results to the orchestrator.
- **OpenAI Agents SDK**'s `output_guardrail` tripped a tripwire that
  nothing ever caught, so "retry with a wider window" never actually
  happened. Added `run_specialist_with_retry`, which catches
  `OutputGuardrailTripwireTriggered` and reruns with a doubled window.

Also fixed: persistence keyed by version-stripped canonical arXiv ID
instead of title (a reworded title used to dodge dedup entirely);
atomic temp-file+rename writes; a future-dated `published` timestamp
no longer passes the recency filter; `cat:math.*` replaced with an
explicit list of the 32 real math subject-class codes (the wildcard's
behavior against the live API was never verified from this sandbox);
pi.dev's TypeScript client now does real XML parsing via
`fast-xml-parser` instead of regex/string-splitting, checks HTTP
status, and guards against unparseable dates; and — the one the
review called an "architectural inconsistency" — every
implementation's search now **paginates until it passes the day-window
boundary** instead of only ever inspecting the newest 100 submissions,
because without that, widening `days: 14 → 28 → 56` had almost no
effect on any category with more than 100 submissions in 60 days.

## v3 — second external review and fixes

A second external review of v3 confirmed all 12 v1→v2 findings were
correctly fixed, but flagged two remaining problems — one of them
("CrewAI approval still appears architecturally unsafe") the most
important structural finding in either review round — plus a smaller
transactional nuance and a pagination-truncation nuance. See
`CHANGELOG.md` for the complete before/after and how each was
verified.

- **`mark_published()` was atomic against corruption, not against a
  concurrent read-modify-write race.** The v2 docstring overstated what
  `os.replace()` buys: it makes a single *write* atomic, but two
  processes can still race a full read-modify-write and silently drop
  one's update. Fixed with an `fcntl.flock`-based lock held across the
  whole read+merge+write in `mark_published()`. Proven, not just
  argued: a 50-process concurrent stress test lost zero updates with
  the lock in place, and a control test reproducing the old unlocked
  pattern under identical load lost 9 of 10 — confirming both that the
  bug was real and that the fix closes it. (This is the claim the
  earlier version of this README also stated too strongly; it's
  corrected here.)
- **CrewAI's approval gate was enforced by LLM instruction-following,
  not by the harness.** The v2 fix made `publish_digest` a tool the
  Editor agent was *told* to call only after approval — but the agent
  still held that tool at all times, so the actual safety property
  depended on the model correctly honoring an instructed ordering, a
  materially weaker guarantee than the Claude Agent SDK's `PreToolUse`
  hook (which can programmatically deny the call). Fixed by removing
  the mutating tool from the agent entirely: the Editor's `editor_task`
  now returns a structured `DigestDraft` (`output_pydantic`), and the
  actual approval prompt and publish both happen in plain host-side
  Python in `__main__`, completely outside any agent's control. There
  is now no path — correct instruction-following or not — by which the
  LLM can publish early. This moves CrewAI out of the "instruction-only"
  category in the table below and into the same host-enforced category
  as LangGraph and the Claude Agent SDK, just implemented with a plain
  `input()` instead of a graph-native interrupt or a hook.
- **digest.md write + `mark_published()` aren't one atomic operation.**
  If the second step fails after the first succeeds, a digest could be
  left on disk describing articles never actually recorded as
  published. Mitigated (not fully solved — a true fix needs a real
  database, as the review noted) with rollback-on-failure: if
  `mark_published()` raises, the just-written `digest.md` is deleted
  and the failure surfaced loudly, so a failed publish is always safe
  to retry. Applied to every implementation that performs this write
  pair, including the instruction-driven pi.dev and omp.sh.
- **A capped page scan could look identical to an exhaustive one.**
  `_fetch_entries_for_window`'s `MAX_PAGES` safety cap meant a
  sufficiently active category could stop scanning before reaching the
  actual date cutoff with no signal to the caller. Every
  implementation's search now also reports a `truncated: bool`, and
  every digest surfaces it as a caveat note when true, instead of
  silently presenting a capped scan as complete.

## The task

1. Search arXiv **physics** categories (quant-ph, hep-th, cond-mat) for
   lecture-notes-style papers from the last 2 weeks on quantum
   mechanics, QFT, or solid state physics.
2. Search arXiv **math** categories for lecture-notes-style papers from
   the last 2 weeks (any subject).
3. If either search returns fewer than 3 hits, widen the window
   (double it, cap 60 days) and retry, up to 2 retries.
4. Merge, filter out anything already published in a previous run
   (persisted state, read-only at draft time), and produce one
   Markdown digest.
5. Require a human approval step before "publishing" (writing the
   final `digest.md` and recording its articles as published).

`shared/arxiv_client.py` and `shared/state_store.py` hold the piece
that's meant to be identical everywhere — the arXiv Atom API call
(with pagination), the keyword filters, and the published-state store
— so every Python-based implementation below is orchestration logic
only. **One exception, called out explicitly rather than left
implicit** (this was the review's "architectural inconsistency"
finding): pi.dev and omp.sh cannot import Python, so
`pi_dev/arxiv_tools.ts` is a from-scratch TypeScript reimplementation.
Its keyword lists (`PHYSICS_TOPIC_KEYWORDS`, `LECTURE_KEYWORDS`) and
category lists are kept byte-identical in spirit to the Python side by
hand, with a comment in each file pointing at its counterpart — but
"kept in sync by hand" is a real, standing maintenance burden this
project accepts rather than hides.

## Status of what's included

Every Python-based implementation was verified in this environment to
**import cleanly and construct its full object graph** (agents, tasks,
tools, handoffs/gather, the compiled LangGraph state graph, the Claude
Agent SDK's MCP server/subagents) without errors. Beyond that, this
revision adds **behavioral, offline tests** for the specific bugs the
review found — with real network and LLM calls mocked out, since this
sandbox's network allowlist blocks `export.arxiv.org` and no API keys
are configured here:

- `shared/arxiv_client.py`: pagination genuinely fetches more pages
  when the window widens (verified: `days=14` fetches 1 page,
  `days=150` fetches 2, against a mocked multi-page feed), and the
  returned `truncated` flag correctly distinguishes a scan that
  exhausted the feed or reached the window boundary naturally
  (`False`) from one that hit the page cap first (`True`); a
  future-dated entry is rejected; `canonicalize_id` strips version
  suffixes correctly.
- `shared/state_store.py`: `filter_unpublished` never writes (checked
  by asserting the file doesn't exist after calling it); a rejected
  digest's articles reappear identically on the next call; approving
  via `mark_published` persists them; a subsequent run correctly
  excludes them; a version-bumped resubmission (`v1` → `v2`) still
  dedupes via canonical ID; a 50-process concurrent
  `multiprocessing` stress test against `mark_published` lost zero
  updates with the `fcntl.flock` lock in place, and an equivalent
  control test reproducing the old unlocked read-modify-write under
  identical load lost 9 of 10 updates, confirming the race was real
  and the lock fixes it.
- **LangGraph**: a full simulated run through the compiled graph —
  reject leaves state empty and the same articles reappear next run;
  approve persists them; a third run correctly excludes them; a
  `physics_truncated` flag correctly produces a caveat line in the
  digest markdown when the mocked search reports it; the
  `merge_and_dedupe` fan-in barrier tested directly against an uneven
  branch scenario (physics needs a widen-retry, math doesn't) —
  confirmed `merge_and_dedupe` runs exactly once, only after both
  branches finish, and that the digest shown at the human-approval
  interrupt matches what `merge_and_dedupe` actually produced (this
  was not true before `defer=True` was added: the same scenario
  triggered two merge calls and an approval on incomplete data).
- **CrewAI**: `editor.tools` confirmed to contain only
  `filter_unpublished_titles` (no publish-capable tool present at
  all); `editor_task.output_pydantic is DigestDraft` and
  `editor_task.human_input is False` confirmed directly; the
  host-side `publish()` function tested directly for both a normal
  success (file written, state marked) and a simulated
  `mark_published` failure (confirmed rollback deletes `digest.md`
  and re-raises); `search_physics_tool` confirmed to surface
  `truncated: True` correctly in its JSON payload.
- **OpenAI Agents SDK**: the retry wrapper tested by mocking
  `Runner.run` to simulate three tripwire-then-success calls,
  confirming the actual widen sequence `14 → 28 → 56`; the
  `asyncio.gather` fan-out timed to confirm it runs concurrently
  (~0.2s wall time for two 0.2s calls, not ~0.4s); the tool functions'
  real call path (via `search_physics.__wrapped__`) tested for the
  same reject/approve sequence and confirmed to return a
  `SearchToolResult(truncated=...)` correctly for both a capped and a
  non-capped mocked scan; `publish_digest` tested directly for both a
  normal success and a simulated `mark_published` failure (confirmed
  rollback deletes `digest.md` before the error string is returned).
- **Claude Agent SDK**: the MCP tool handlers (via their `.handler`
  attribute) tested directly for the same reject/approve sequence and
  confirmed to return `{articles, truncated}` correctly for both a
  capped and a non-capped mocked scan; the `PreToolUse` hook function
  tested in isolation to confirm it returns a `deny` decision on
  rejection, `{}` (allow) on approval, and passes through untouched
  for any non-`publish_digest` tool call; `publish_tool` tested
  directly for both a normal success and a simulated `mark_published`
  failure (confirmed rollback deletes `digest.md` and returns an
  `is_error` result rather than silently succeeding).
- **pi.dev's TypeScript client**: type-checked with `tsc --noEmit`
  (zero errors); the `fast-xml-parser`-based parsing tested against
  entity-encoded and version-suffixed mock XML; HTTP-status-check,
  NaN-date-guard, and pagination logic each tested directly in Node;
  a mocked-`fetch` runtime test confirms `arxivSearch` reports
  `truncated: true` when a feed always returns full pages up to
  `MAX_PAGES`, and `truncated: false` when a feed runs out naturally
  within one page.

What still could not be verified here: an actual end-to-end run
against the live arXiv API, and an actual LLM-driven run of any of the
four Python frameworks (no API keys in this sandbox). Run these from a
normal machine with network access and the relevant API key to see a
full run.

## Side-by-side

| | Orchestration unit | Parallel fan-out | Retry/widen mechanism | Persistence | Human approval | Distinctive primitive |
|---|---|---|---|---|---|---|
| **LangGraph** | Graph nodes + edges | Native (two branches from `__start__`), joined at `merge_and_dedupe` via `defer=True` — a plain multi-edge convergence does **not** wait for both branches on its own when they can loop a different number of times | Explicit conditional edge, re-enters search node | `MemorySaver` checkpointer; state written **only** in the `publish` node, post-approval | `interrupt()` + `Command(resume=...)` — graph genuinely suspends | Explicit, drawable state graph |
| **CrewAI** | Role-based Agents + Tasks | Sequential by default; editor task's `context=[...]` waits on both research tasks | Agent's own tool-calling loop (instructed to retry, not enforced) | The Editor agent has **no publish-capable tool at all** — it returns a structured `DigestDraft` (`output_pydantic`); the actual file write + `mark_published()` happen in plain host-side Python, outside any agent's control | A plain `input()` call in host code the agent has no path to bypass, since it never held a tool that could publish | Role/goal/backstory mental model |
| **OpenAI Agents SDK** | Small Agents + explicit `asyncio.gather(Runner.run(...))` | Genuine (`asyncio.gather`, timed and confirmed concurrent) | `output_guardrail` tripwire **caught** by `run_specialist_with_retry`, which reruns with a doubled window | A `publish_digest` tool; state written only there, on approval | A tool call (`request_human_approval`) the orchestrator must invoke | Guardrail exception as a real retry trigger |
| **Claude Agent SDK** | One primary agent + Task-tool subagents | Two subagents launched via `Task` | Subagent's own instructed loop (like CrewAI) | MCP `publish_digest` tool; state written only if the hook allows the call | **`PreToolUse` hook** denies the `publish_digest` call until approved — enforced by the harness, not the model | "Give one agent a computer"; hooks intercept tool execution |
| **pi.dev** | One session, one model, bigger toolbox | None — sequential, inside one transcript | Written as an instruction in `AGENTS.md`; nothing enforces it | Model reads `published.json` read-only at draft time; writes it only in the final, explicitly-approved step | Plain conversational question; nothing blocks an early write except the instructions | Minimal 4-tool core + a single TS extension |
| **omp.sh** | One orchestrator + native subagent spawn | **Native parallel task spawn** (physics + math subagents at once) | Each subagent's own instructed loop | Same read-then-write-only-on-approval split, enforced by instruction only (`omp.config.toml` says so explicitly) | Same gap as pi.dev — instruction-only, not harness-enforced | Persistent Python/Bun kernel callable from the agent's own tools |

## What this actually teaches

- **Control enforcement vs. model discretion — and instructing a model
  better is not the same as removing its discretion.** LangGraph
  (`interrupt()`), the Claude Agent SDK (`PreToolUse` hook), and CrewAI
  (after the v3 fix) all now make the *state write itself* something
  the model has no path to trigger without going through a real gate;
  OpenAI's SDK still relies on the orchestrator agent choosing to call
  an approval tool before a publish tool, same as pi.dev and omp.sh
  rely on the model following an instruction. The CrewAI revision is
  the clearest illustration of the difference between the two
  strategies: the v2 fix tried to gate `publish_digest` by *instructing*
  the Editor agent to call it only after approval, and a second review
  round correctly pointed out that's not a permission gate, just a
  hope. The v3 fix doesn't gate the tool better — it removes the tool
  from the agent's reach entirely and does the actual write in host
  code the model never touches. That's the general pattern worth
  taking away: a safety property that depends on an LLM correctly
  interpreting an instruction is strictly weaker than one where the
  capability simply isn't reachable from inside the model's control
  flow, no matter how carefully the instruction is worded.
- **A guardrail is a validator, not a controller, until something
  catches it.** The OpenAI Agents SDK fix is the clearest illustration:
  `output_guardrail` on its own only produces a pass/fail signal
  (a raised exception). Turning "fail" into "retry with different
  parameters" required an explicit `try`/`except` wrapper in
  orchestrator code — the guardrail is necessary but not sufficient.
- **Where "state" lives.** LangGraph's checkpointer persists the
  *entire graph state* (not just the published-articles file) keyed by
  a thread ID, so a crashed run could resume mid-graph. Everyone else
  treats persistence as "a function that reads/writes one JSON file" —
  functionally equivalent for this task, but LangGraph's version
  generalizes further.
- **Parallelism is a spectrum, and "looks parallel" isn't the same as
  "is parallel."** LangGraph and omp.sh have real native fan-out.
  OpenAI's SDK needed an explicit `asyncio.gather` — its `handoffs`
  primitive, despite superficially looking like delegation, is actually
  sequential control transfer and does not fan out on its own. CrewAI's
  default `Process.sequential` waits on `context=[...]` rather than
  truly forking. pi.dev has no fan-out primitive at all.
- **Fanning out is easy; fanning back in correctly is the hard part,
  especially across branches of uneven length.** LangGraph's own fix
  in v4 is the clearest example in this project: two parallel branches
  converging on the same node via ordinary edges looks like a natural
  join, and reads like one in a quick skim — but it's only a real
  barrier if both branches finish in the same superstep. A retry loop
  on just one branch breaks that assumption silently: nothing raises
  an error, the graph just runs the "joined" node once per branch
  instead of once total, on whatever partial state exists each time.
  The fix (`defer=True`) is a one-line, well-documented feature made
  for exactly this — but only if you know a plain multi-edge
  convergence isn't already sufficient, which is exactly the kind of
  assumption that's easy to state confidently in a comment and never
  actually exercise with branches of different lengths.
- **Vendor lock-in is inversely related to structure.** The two most
  structured tools (LangGraph, CrewAI) are model-agnostic. The two
  "give the agent a computer" harnesses (Claude Agent SDK, omp.sh) are
  the most capable at real OS-level work (files, shell, a live Python
  kernel) but hand you a single powerful agent plus a way to spawn
  narrow helpers, not a graph or a role hierarchy.

## Layout

```
arxiv_digest_agents/
├── CHANGELOG.md              # v1→v2 (12 findings), v2→v3 (4 findings), v3→v4 (1 finding), v5/v6 (usability) reviews + fixes
├── shared/
│   ├── arxiv_client.py       # arXiv search/filter/pagination, used by every Python impl
│   └── state_store.py        # published-state store: filter_unpublished / mark_published split
├── langgraph/digest_graph.py
│   └── output/digest.md      # generated at run time, not checked in
├── crewai/digest_crew.py
│   └── output/digest.md      # generated at run time, not checked in
├── openai_agents_sdk/digest_agents.py
│   └── output/digest.md      # generated at run time, not checked in
├── claude_agent_sdk/digest_agent.py
│   └── output/digest.md      # generated at run time, not checked in
├── pi_dev/{AGENTS.md, arxiv_tools.ts, package.json, prompts/arxiv_digest_prompt.md, README.md}
│   └── output/digest.md      # generated at run time, not checked in
├── omp_sh/{omp.config.toml, SYSTEM.md, prompts/*.md, README.md}
│   └── output/digest.md      # generated at run time, not checked in
└── requirements.txt
```

Every implementation writes its generated digest to its own
`output/digest.md`, uniformly, so a generated artifact is never named
or located the same as a hand-written instruction/prompt file (the
specific incident that motivated this: pi.dev used to have a prompt
template and its generated output both named `digest.md`, and a
cleanup script matching on filename once deleted the wrong one).
